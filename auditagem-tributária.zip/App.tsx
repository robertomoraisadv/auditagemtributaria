
import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './pages/Dashboard';
import { RegisterClient } from './pages/RegisterClient';
import { NewAudit } from './pages/NewAudit'; 
import { SalesSimulator } from './pages/SalesSimulator';
import { TechnicalTables } from './pages/TechnicalTables';
import { ReportsHistory } from './pages/ReportsHistory';
import { PartnerManagement } from './pages/PartnerManagement';
import { SystemSettings } from './pages/SystemSettings';
import { ProductionCRM } from './pages/ProductionCRM'; 
import { ManagementReports } from './pages/ManagementReports';
import { Login } from './pages/Login';
import { ViewState, User } from './types';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<ViewState>('dashboard');

  useEffect(() => {
    const sessionUser = sessionStorage.getItem('at_user_session');
    if (sessionUser) {
      const user = JSON.parse(sessionUser);
      setCurrentUser(user);
      if (user.funcao === 'parceiro' && currentView === 'dashboard') setCurrentView('sales_simulator');
    }
  }, []);

  const handleLogin = (user: User) => {
    sessionStorage.setItem('at_user_session', JSON.stringify(user));
    setCurrentUser(user);
    user.funcao === 'parceiro' ? setCurrentView('sales_simulator') : setCurrentView('dashboard');
  };

  const handleLogout = () => {
    sessionStorage.removeItem('at_user_session');
    setCurrentUser(null);
    setCurrentView('dashboard');
  };

  if (!currentUser) return <Login onLoginSuccess={handleLogin} />;

  const renderContent = () => {
    if (currentUser.funcao === 'parceiro' && ['audit_xml', 'technical_tables', 'partner_management', 'system_settings', 'dashboard', 'production_crm', 'management_reports'].includes(currentView)) {
      if (currentView === 'audit_xml') return <NewAudit currentUser={currentUser} />;
      return <SalesSimulator currentUser={currentUser} />;
    }

    switch (currentView) {
      case 'dashboard': return <Dashboard />;
      case 'partner_management': return <PartnerManagement />;
      case 'production_crm': return <ProductionCRM />;
      case 'management_reports': return <ManagementReports />;
      case 'system_settings': return <SystemSettings />;
      case 'register_client': return <RegisterClient currentUser={currentUser} onNavigate={setCurrentView} />;
      case 'sales_simulator': return <SalesSimulator currentUser={currentUser} />;
      case 'audit_xml': return <NewAudit currentUser={currentUser} />;
      case 'technical_tables': return <TechnicalTables />;
      case 'reports_history': return <ReportsHistory currentUser={currentUser} />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900 font-sans">
      <Sidebar currentView={currentView} onChangeView={setCurrentView} onLogout={handleLogout} userRole={currentUser.funcao} userName={currentUser.nome} />
      <main className="flex-1 p-8 overflow-y-auto">
        <div className="max-w-7xl mx-auto">{renderContent()}</div>
      </main>
    </div>
  );
};

export default App;
