
import React from 'react';
import { ViewState, Role } from '../types';
import { LayoutDashboard, UserPlus, Calculator, FileSearch, Table2, History, LogOut, Users, Settings, Briefcase, BarChart3 } from 'lucide-react';

interface SidebarProps {
  currentView: ViewState;
  onChangeView: (view: ViewState) => void;
  onLogout: () => void;
  userRole: Role;
  userName: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onChangeView, onLogout, userRole, userName }) => {
  const allMenuItems = [
    { id: 'dashboard', label: 'Painel de Controle', icon: LayoutDashboard, roles: ['admin'] },
    { id: 'production_crm', label: 'Produção & Financeiro', icon: Briefcase, roles: ['admin'] },
    { id: 'management_reports', label: 'Relatórios BI', icon: BarChart3, roles: ['admin'] },
    { id: 'partner_management', label: 'Gestão de Parceiros', icon: Users, roles: ['admin'] },
    { id: 'register_client', label: 'Cadastrar Cliente', icon: UserPlus, roles: ['admin', 'parceiro'] },
    { id: 'sales_simulator', label: 'Simulador de Potencial', icon: Calculator, roles: ['admin', 'parceiro'] },
    { id: 'audit_xml', label: 'Auditoria Fiscal (XML)', icon: FileSearch, roles: ['admin'] },
    { id: 'technical_tables', label: 'Tabelas Técnicas', icon: Table2, roles: ['admin'] },
    { id: 'reports_history', label: 'Histórico de Relatórios', icon: History, roles: ['admin', 'parceiro'] },
    { id: 'system_settings', label: 'Configurações do Sistema', icon: Settings, roles: ['admin'] },
  ];

  const availableItems = allMenuItems.filter(item => item.roles.includes(userRole));

  return (
    <div className="w-64 bg-slate-900 text-white min-h-screen flex flex-col shadow-xl z-10 sticky top-0 h-screen">
      <div className="p-6 border-b border-slate-700">
        <h1 className="text-xl font-bold text-blue-400 tracking-tight">Auditagem<span className="text-white">TributárIA</span></h1>
        <p className="text-xs text-slate-400 mt-1">Olá, {userName.split(' ')[0]}</p>
        <span className="inline-block mt-2 px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-800 text-slate-300 border border-slate-700">
          {userRole}
        </span>
      </div>

      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {availableItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onChangeView(item.id as ViewState)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all duration-200 ${
                isActive ? 'bg-blue-600 text-white shadow-md' : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icon size={18} />
              <span className="text-sm font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-700">
        <button onClick={onLogout} className="w-full flex items-center gap-3 px-4 py-2 text-red-400 hover:bg-red-900/20 hover:text-red-300 rounded-lg transition-colors">
          <LogOut size={18} />
          <span className="text-sm font-medium">Sair do Sistema</span>
        </button>
      </div>
    </div>
  );
};
