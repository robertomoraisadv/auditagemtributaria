
import React, { useState, useEffect } from 'react';
import { db } from '../services/db';
import { testarConexaoSMTP } from '../services/emailService';
import { Settings, Save, CheckCircle, Mail, Lock, AlertTriangle, Terminal, XCircle, Database, Download } from 'lucide-react';

export const SystemSettings: React.FC = () => {
  const [formData, setFormData] = useState({ smtp_email: '', smtp_senha: '' });
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  useEffect(() => {
    const configs = db.getAllConfig();
    setFormData({ smtp_email: configs.smtp_email || '', smtp_senha: configs.smtp_senha || '' });
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (testResult) setTestResult(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    db.setConfig('smtp_email', formData.smtp_email);
    db.setConfig('smtp_senha', formData.smtp_senha);
    setMessage({ type: 'success', text: 'Configurações salvas com sucesso.' });
    setTestResult(null);
    setTimeout(() => setMessage(null), 3000);
  };

  const handleTestConnection = async () => {
    db.setConfig('smtp_email', formData.smtp_email);
    db.setConfig('smtp_senha', formData.smtp_senha);
    setIsTesting(true);
    setTestResult(null);
    try {
      const result = await testarConexaoSMTP();
      setTestResult(result);
    } catch (error: any) {
      setTestResult({ success: false, message: `System Error: ${error.message}` });
    } finally {
      setIsTesting(false);
    }
  };

  // ROTINA DE BACKUP
  const handleDownloadBackup = () => {
    const jsonString = db.createBackup();
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `backup_auditagem_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 animate-fade-in max-w-2xl mx-auto">
      <header>
        <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
          <Settings className="text-blue-600" />
          Configurações do Sistema
        </h2>
        <p className="text-slate-500">Parâmetros globais, backup e credenciais.</p>
      </header>

      {/* BOX BACKUP - NOVO */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center gap-2 mb-4 border-b border-slate-100 pb-4">
          <Database className="text-indigo-500" size={20} />
          <h3 className="font-semibold text-slate-800">Manutenção e Backup</h3>
        </div>
        <p className="text-sm text-slate-600 mb-4">
          Faça o download de todos os dados do sistema (Clientes, Processos e Usuários) em formato JSON.
        </p>
        <button onClick={handleDownloadBackup} className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg transition-colors">
          <Download size={18} /> Baixar Backup Completo (.db)
        </button>
      </div>

      {/* BOX DE CONFIGURAÇÃO DE EMAIL */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center gap-2 mb-6 border-b border-slate-100 pb-4">
          <Mail className="text-slate-500" size={20} />
          <h3 className="font-semibold text-slate-800">Servidor de E-mail (SMTP)</h3>
        </div>

        {message && (
          <div className={`mb-6 p-3 rounded-lg text-sm flex items-center gap-2 ${message.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
            <CheckCircle size={16} />
            {message.text}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">E-mail do Sistema (Remetente)</label>
            <input type="email" name="smtp_email" value={formData.smtp_email} onChange={handleChange} className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Senha de App</label>
            <input type="password" name="smtp_senha" value={formData.smtp_senha} onChange={handleChange} className="w-full px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <button type="submit" className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 px-6 rounded-lg transition-colors shadow-sm">
            <Save size={18} /> Salvar Configurações
          </button>
        </form>
      </div>

      {/* BOX DE TESTE E DIAGNÓSTICO */}
      <div className="bg-slate-50 rounded-xl shadow-inner border border-slate-200 p-6">
        <div className="flex items-center gap-2 mb-4">
          <Terminal className="text-slate-600" size={20} />
          <h3 className="font-semibold text-slate-800">Diagnóstico de Conexão</h3>
        </div>
        
        <button 
          onClick={handleTestConnection}
          disabled={isTesting || !formData.smtp_email}
          className={`flex items-center gap-2 font-semibold py-3 px-6 rounded-lg transition-all w-full md:w-auto justify-center ${
            isTesting 
            ? 'bg-slate-300 text-slate-500 cursor-not-allowed' 
            : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm hover:shadow'
          }`}
        >
          {isTesting ? 'Testando...' : '📧 Enviar E-mail de Teste Agora'}
        </button>

        {testResult && (
          <div className={`mt-6 p-4 rounded-md border-l-4 shadow-sm flex items-start gap-3 animate-fade-in ${testResult.success ? 'bg-green-50 border-green-500 text-green-800' : 'bg-red-50 border-red-500 text-red-800'}`}>
            {testResult.success ? <CheckCircle size={20} /> : <XCircle size={20} />}
            <div className="text-sm font-mono break-all">{testResult.message}</div>
          </div>
        )}
      </div>
    </div>
  );
};
