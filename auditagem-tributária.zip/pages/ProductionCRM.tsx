

import React, { useState, useEffect } from 'react';
import { db } from '../services/db';
import { AuditProcess, User, ProcessStatus, FinancialStatus, PartnerPaymentStatus, Client } from '../types';
import { Wallet, Landmark, Save, CheckCircle2, AlertCircle, TrendingUp, Trash2, Users, Briefcase, Filter } from 'lucide-react';

export const ProductionCRM: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'ESTEIRA' | 'COMISSOES'>('ESTEIRA');
  const [showOnlyActive, setShowOnlyActive] = useState(true);
  const [processes, setProcesses] = useState<AuditProcess[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [edits, setEdits] = useState<Record<string, Partial<AuditProcess>>>({});
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setProcesses(db.getProcesses(undefined, true));
    setUsers(db.getUsers());
    setClients(db.getClients(undefined, true));
  };

  const handleEdit = (id: string, field: keyof AuditProcess, value: any) => {
    setEdits(prev => ({
      ...prev,
      [id]: { ...prev[id], [field]: value }
    }));
  };

  const handleSaveProcess = (id: string) => {
    if (db.updateProcess(id, edits[id] || {})) {
      setMessage({ type: 'success', text: 'Dados atualizados com sucesso!' });
      setEdits(prev => {
        const n = { ...prev };
        delete n[id];
        return n;
      });
      refreshData();
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const handleDeleteProcess = (id: string) => {
    if (confirm('⚠️ ATENÇÃO: Deseja excluir permanentemente este processo? Esta ação não pode ser desfeita.')) {
      if (db.deleteProcess(id)) {
        setMessage({ type: 'success', text: 'Processo excluído da base.' });
        refreshData();
        setTimeout(() => setMessage(null), 3000);
      }
    }
  };

  const handlePayCommission = (id: string) => {
    if (db.updateProcess(id, { status_pgto_parceiro: 'Pago', data_pagamento: new Date().toISOString() })) {
      setMessage({ type: 'success', text: 'Comissão marcada como PAGA!' });
      refreshData();
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const fmtBRL = (v: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);

  // Fixed: Added 'Cancelado' to ProcessStatus type in types.ts, so it is now assignable here
  const STATUS_OPTS: ProcessStatus[] = ['Prospecção', 'Em Análise', 'Protocolado', 'Homologado', 'Finalizado', 'Cancelado', 'Arquivado'];
  const FIN_OPTS: FinancialStatus[] = ['A Faturar', 'Aguardando Pagamento', 'Pago', 'Inadimplente'];

  // Lógica de Filtro
  // Fixed: 'Cancelado' is now a valid ProcessStatus, resolving type overlap error in comparison
  const filteredProcesses = showOnlyActive 
    ? processes.filter(p => p.status_processo !== 'Finalizado' && p.status_processo !== 'Cancelado')
    : processes;

  // Métricas
  const totalRecuperado = filteredProcesses.reduce((acc, p) => acc + (p.valor_homologado || 0), 0);
  const totalHonorarios = filteredProcesses.filter(p => p.status_pgto_cliente === 'Pago').reduce((acc, p) => acc + (p.valor_honorarios || 0), 0);
  const comissoesPendentes = filteredProcesses.filter(p => p.status_pgto_parceiro !== 'Pago').reduce((acc, p) => acc + (p.valor_comissao_parceiro || 0), 0);

  return (
    <div className="space-y-8 animate-fade-in pb-20 max-w-7xl mx-auto">
      <header className="border-b pb-4 flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-black text-slate-900 flex items-center gap-3 tracking-tighter uppercase italic">
            <Wallet className="text-emerald-600" size={32} /> GESTÃO & PRODUÇÃO <span className="text-emerald-500">Master</span>
          </h2>
          <p className="text-sm text-slate-500 font-medium italic">Monitoramento em tempo real do faturamento tributário.</p>
        </div>
        
        <div className="flex items-center gap-3 bg-slate-100 p-1 rounded-2xl border">
          <button 
            onClick={() => setShowOnlyActive(true)}
            className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${showOnlyActive ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500'}`}
          >Ativos</button>
          <button 
            onClick={() => setShowOnlyActive(false)}
            className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${!showOnlyActive ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500'}`}
          >Histórico Total</button>
        </div>
      </header>

      {/* KPI BOXES */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-8 rounded-[32px] border shadow-sm flex items-center gap-4">
           <div className="bg-emerald-100 p-4 rounded-2xl text-emerald-600"><TrendingUp size={24} /></div>
           <div>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Potencial Homologado</span>
              <div className="text-xl font-black text-slate-800">{fmtBRL(totalRecuperado)}</div>
           </div>
        </div>
        <div className="bg-white p-8 rounded-[32px] border shadow-sm flex items-center gap-4">
           <div className="bg-blue-100 p-4 rounded-2xl text-blue-600"><Landmark size={24} /></div>
           <div>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Honorários Brutos</span>
              <div className="text-xl font-black text-blue-600">{fmtBRL(totalHonorarios)}</div>
           </div>
        </div>
        <div className="bg-white p-8 rounded-[32px] border shadow-sm flex items-center gap-4">
           <div className="bg-orange-100 p-4 rounded-2xl text-orange-600"><Briefcase size={24} /></div>
           <div>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Comissões Devidas</span>
              <div className="text-xl font-black text-orange-600">{fmtBRL(comissoesPendentes)}</div>
           </div>
        </div>
      </div>

      {message && (
        <div className={`p-4 rounded-2xl text-xs font-black flex items-center gap-2 animate-pop-in ${message.type === 'success' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-red-50 text-red-600 border border-red-100'}`}>
          {message.type === 'success' ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />}
          {message.text}
        </div>
      )}

      {/* SUB-ABAS */}
      <div className="flex bg-slate-200 p-1.5 rounded-[24px] w-fit shadow-inner">
        <button onClick={() => setActiveTab('ESTEIRA')} className={`px-10 py-3 text-[10px] font-black rounded-[20px] transition-all uppercase tracking-widest ${activeTab === 'ESTEIRA' ? 'bg-white text-blue-600 shadow-lg' : 'text-slate-500'}`}>
          Esteira de Produção
        </button>
        <button onClick={() => setActiveTab('COMISSOES')} className={`px-10 py-3 text-[10px] font-black rounded-[20px] transition-all uppercase tracking-widest ${activeTab === 'COMISSOES' ? 'bg-white text-blue-600 shadow-lg' : 'text-slate-500'}`}>
          Controle de Comissões
        </button>
      </div>

      {activeTab === 'ESTEIRA' ? (
        <div className="bg-white rounded-[40px] shadow-2xl border border-slate-100 overflow-hidden overflow-x-auto">
          <table className="w-full text-[11px] text-left">
            <thead className="bg-slate-900 text-white font-black uppercase italic tracking-widest">
              <tr>
                <th className="px-6 py-4">Ciclo / Cliente</th>
                <th className="px-6 py-4">Status Atual</th>
                <th className="px-6 py-4">Valor Homolog.</th>
                <th className="px-6 py-4 text-center">Honorários</th>
                <th className="px-6 py-4">Financeiro</th>
                <th className="px-6 py-4 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredProcesses.map(p => {
                const client = clients.find(c => c.id === p.id_cliente);
                const edit = edits[p.id] || {};
                const isEdited = Object.keys(edit).length > 0;

                return (
                  <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-black text-slate-800 uppercase">{client?.razao_social || 'Lead Externo'}</div>
                      <div className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">Criado em {new Date(p.created_at).toLocaleDateString()}</div>
                    </td>
                    <td className="px-6">
                       <select 
                        value={edit.status_processo || p.status_processo} 
                        onChange={e => handleEdit(p.id, 'status_processo', e.target.value)}
                        className={`bg-slate-50 border-2 rounded-lg px-2 py-1 font-bold text-[10px] outline-none ${
                          (edit.status_processo || p.status_processo) === 'Homologado' ? 'border-blue-400 text-blue-600' : 'border-slate-100 text-slate-500'
                        }`}
                      >
                        {STATUS_OPTS.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </td>
                    <td className="px-6">
                      <input 
                        type="number" 
                        value={edit.valor_homologado ?? p.valor_homologado} 
                        onChange={e => handleEdit(p.id, 'valor_homologado', parseFloat(e.target.value))}
                        className="w-28 bg-slate-50 border-2 border-slate-100 rounded-lg px-2 py-1 font-black text-blue-600 outline-none text-right"
                      />
                    </td>
                    <td className="px-6 text-center font-bold text-slate-400 italic">
                      {fmtBRL(p.valor_honorarios)}
                    </td>
                    <td className="px-6">
                       <select 
                        value={edit.status_pgto_cliente || p.status_pgto_cliente} 
                        onChange={e => handleEdit(p.id, 'status_pgto_cliente', e.target.value)}
                        className={`border-2 rounded-lg px-2 py-1 font-black text-[10px] outline-none ${
                          (edit.status_pgto_cliente || p.status_pgto_cliente) === 'Pago' ? 'border-emerald-200 bg-emerald-50 text-emerald-700' : 'border-slate-100 bg-slate-50 text-slate-500'
                        }`}
                      >
                        {FIN_OPTS.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </td>
                    <td className="px-6 text-center space-x-2">
                       {isEdited && (
                         <button onClick={() => handleSaveProcess(p.id)} className="bg-emerald-600 text-white p-2.5 rounded-xl shadow-lg hover:bg-emerald-700 transition-all">
                            <Save size={14} />
                         </button>
                       )}
                       <button onClick={() => handleDeleteProcess(p.id)} className="text-slate-300 hover:text-red-500 transition-colors p-2.5">
                          <Trash2 size={14} />
                       </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="bg-white rounded-[40px] shadow-2xl border border-slate-100 overflow-hidden overflow-x-auto">
          <table className="w-full text-[11px] text-left">
            <thead className="bg-slate-900 text-white font-black uppercase italic tracking-widest">
              <tr>
                <th className="px-6 py-4">Membro Parceiro</th>
                <th className="px-6 py-4">Cliente</th>
                <th className="px-6 py-4">Valor Honorário</th>
                <th className="px-6 py-4">Comissão Devida</th>
                <th className="px-6 py-4 text-center">Status Pagamento</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredProcesses.filter(p => p.valor_comissao_parceiro > 0).map(p => {
                const partner = users.find(u => u.id === p.id_parceiro);
                const client = clients.find(c => c.id === p.id_cliente);
                const isClientPaid = p.status_pgto_cliente === 'Pago';

                return (
                  <tr key={p.id} className="hover:bg-slate-50">
                    <td className="px-6 py-4 font-black text-slate-800">{partner?.nome}</td>
                    <td className="px-6 py-4 font-medium text-slate-500">{client?.razao_social || 'Lead'}</td>
                    <td className="px-6 py-4 font-bold">{fmtBRL(p.valor_honorarios)}</td>
                    <td className="px-6 py-4 font-black text-emerald-600">{fmtBRL(p.valor_comissao_parceiro)}</td>
                    <td className="px-6 text-center">
                       {p.status_pgto_parceiro === 'Pago' ? (
                         <span className="bg-slate-100 text-slate-400 px-4 py-1.5 rounded-full font-black text-[9px] uppercase italic">Liquidado</span>
                       ) : (
                         <div className="flex items-center justify-center gap-3">
                            <span className={`px-3 py-1 rounded-full font-black text-[9px] uppercase ${isClientPaid ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                              {isClientPaid ? 'Disponível' : 'Aguardando'}
                            </span>
                            {isClientPaid && (
                              <button onClick={() => handlePayCommission(p.id)} className="bg-slate-900 text-white p-2 rounded-xl hover:bg-black transition-all shadow-md">
                                <CheckCircle2 size={12} />
                              </button>
                            )}
                         </div>
                       )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};