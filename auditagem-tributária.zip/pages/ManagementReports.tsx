
import React, { useState, useEffect } from 'react';
import { db } from '../services/db';
import { Client, AuditProcess, User } from '../types';
import { BarChart3, Users, Landmark, Search, FileDown, TrendingUp, PieChart, DollarSign } from 'lucide-react';

export const ManagementReports: React.FC = () => {
  const [clients, setClients] = useState<Client[]>([]);
  const [processes, setProcesses] = useState<AuditProcess[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    setClients(db.getClients(undefined, true));
    setProcesses(db.getProcesses(undefined, true));
    setUsers(db.getUsers());
  }, []);

  const getPartnerName = (id: string) => users.find(u => u.id === id)?.nome || 'Sistema';
  const fmtBRL = (v: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);

  // Métricas
  const totalHomologado = processes.reduce((acc, p) => acc + (p.valor_homologado || 0), 0);
  const totalHonorariosPrevistos = processes.reduce((acc, p) => acc + (p.valor_honorarios || 0), 0);
  const totalHonorariosPagos = processes.filter(p => p.status_pgto_cliente === 'Pago').reduce((acc, p) => acc + (p.valor_honorarios || 0), 0);
  const comissoesPendentes = processes.filter(p => p.status_pgto_parceiro !== 'Pago').reduce((acc, p) => acc + (p.valor_comissao_parceiro || 0), 0);

  return (
    <div className="space-y-8 animate-fade-in pb-20 max-w-7xl mx-auto">
      <header>
        <h2 className="text-3xl font-black text-slate-900 flex items-center gap-3 tracking-tighter uppercase italic">
          <BarChart3 className="text-blue-600" />
          Relatórios Gerenciais <span className="text-blue-500">BI</span>
        </h2>
        <p className="text-slate-500 font-medium">Análise de performance, carteira e obrigações financeiras.</p>
      </header>

      {/* KPI GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-[32px] border shadow-sm">
           <div className="bg-slate-50 w-10 h-10 rounded-xl flex items-center justify-center mb-4 text-slate-400"><TrendingUp size={20} /></div>
           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Total Homologado</span>
           <div className="text-xl font-black text-slate-800">{fmtBRL(totalHomologado)}</div>
        </div>
        <div className="bg-white p-6 rounded-[32px] border shadow-sm">
           <div className="bg-blue-50 w-10 h-10 rounded-xl flex items-center justify-center mb-4 text-blue-500"><Landmark size={20} /></div>
           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Faturamento Honorários</span>
           <div className="text-xl font-black text-blue-600">{fmtBRL(totalHonorariosPrevistos)}</div>
        </div>
        <div className="bg-emerald-50 p-6 rounded-[32px] border border-emerald-100 shadow-sm">
           <div className="bg-emerald-100 w-10 h-10 rounded-xl flex items-center justify-center mb-4 text-emerald-600"><DollarSign size={20} /></div>
           <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest block">Receita Líquida (Pago)</span>
           <div className="text-xl font-black text-emerald-700">{fmtBRL(totalHonorariosPagos)}</div>
        </div>
        <div className="bg-orange-50 p-6 rounded-[32px] border border-orange-100 shadow-sm">
           <div className="bg-orange-100 w-10 h-10 rounded-xl flex items-center justify-center mb-4 text-orange-600"><Users size={20} /></div>
           <span className="text-[10px] font-black text-orange-500 uppercase tracking-widest block">Comissões a Pagar</span>
           <div className="text-xl font-black text-orange-700">{fmtBRL(comissoesPendentes)}</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* CARTEIRA DE CLIENTES */}
        <section className="lg:col-span-2 bg-white rounded-[40px] border shadow-xl overflow-hidden">
          <div className="p-8 border-b flex justify-between items-center">
            <h3 className="font-black text-slate-800 flex items-center gap-2 uppercase italic text-sm">
              <Users size={18} className="text-blue-500" /> Carteira de Clientes Global
            </h3>
            <div className="relative">
               <Search size={14} className="absolute left-3 top-2.5 text-slate-300" />
               <input 
                value={searchTerm} 
                onChange={e => setSearchTerm(e.target.value)} 
                placeholder="Filtrar por nome..." 
                className="bg-slate-50 pl-9 pr-4 py-2 border rounded-xl text-xs font-bold outline-none focus:bg-white transition-all" 
              />
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-[11px] text-left">
              <thead className="bg-slate-50 text-slate-400 font-black uppercase italic">
                <tr>
                  <th className="px-6 py-4">Razão Social / CNPJ</th>
                  <th className="px-6 py-4">Localização</th>
                  <th className="px-6 py-4">Parceiro</th>
                  <th className="px-6 py-4">Cadastro</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {clients.filter(c => c.razao_social.toLowerCase().includes(searchTerm.toLowerCase())).map(c => (
                  <tr key={c.id} className="hover:bg-slate-50">
                    <td className="px-6 py-4">
                      <div className="font-black text-slate-800">{c.razao_social}</div>
                      <div className="text-[9px] text-slate-400 font-bold uppercase">{c.cnpj}</div>
                    </td>
                    <td className="px-6 py-4 text-slate-600 font-medium">{c.cidade} / {c.uf}</td>
                    <td className="px-6 py-4 font-black text-blue-600">{getPartnerName(c.id_parceiro_vinculado)}</td>
                    <td className="px-6 py-4 text-slate-400 font-bold">{new Date(c.data_cadastro).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* CONTAS A PAGAR */}
        <section className="bg-white rounded-[40px] border shadow-xl overflow-hidden h-fit">
          <div className="p-8 border-b flex justify-between items-center">
            <h3 className="font-black text-slate-800 flex items-center gap-2 uppercase italic text-sm">
              <Landmark size={18} className="text-emerald-500" /> Pendências
            </h3>
            <button className="text-blue-600"><FileDown size={18} /></button>
          </div>
          <div className="p-2">
            {processes.filter(p => p.status_pgto_parceiro !== 'Pago' && p.valor_comissao_parceiro > 0).map(p => (
              <div key={p.id} className="p-4 hover:bg-slate-50 rounded-2xl flex justify-between items-center border-b last:border-0 border-slate-50">
                <div>
                  <div className="text-[10px] font-black text-slate-800 uppercase">{getPartnerName(p.id_parceiro)}</div>
                  <div className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">Ref: {p.id.slice(0,8)}</div>
                </div>
                <div className="text-right">
                  <div className="font-black text-emerald-600">{fmtBRL(p.valor_comissao_parceiro)}</div>
                  <div className={`text-[8px] font-black px-2 py-0.5 rounded-full uppercase ${p.status_pgto_cliente === 'Pago' ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                    {p.status_pgto_cliente === 'Pago' ? 'LIBERADO' : 'AGUARDANDO'}
                  </div>
                </div>
              </div>
            ))}
            {processes.filter(p => p.status_pgto_parceiro !== 'Pago' && p.valor_comissao_parceiro > 0).length === 0 && (
              <div className="p-8 text-center text-slate-300 font-black uppercase text-[10px] tracking-widest italic">
                 Nenhuma comissão pendente
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};
