
import React, { useState } from 'react';
import { db, LISTA_UFS, SETORES, cleanNumbers } from '../services/db';
import { RegimeTributario, User, ViewState } from '../types';
import { enviarAlertaNovoLead } from '../services/emailService';
import { Save, Building2, UserCircle, MapPin, AlertCircle, CheckCircle2 } from 'lucide-react';

interface Props {
  currentUser?: User;
  onNavigate?: (view: ViewState) => void;
}

export const RegisterClient: React.FC<Props> = ({ currentUser, onNavigate }) => {
  const [formData, setFormData] = useState({
    cnpj: '', razao_social: '', nome_contato: '', email: '', whatsapp: '',
    uf: 'PA', cidade: '', setor: 'Autopeças', rbt12_atual: '', regime_tributario: RegimeTributario.SIMPLES_COMERCIO
  });
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error' | 'warning', text: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSaving) return;
    
    setIsSaving(true);
    setMessage(null);

    try {
      // 1. Validação Antecipada
      const cnpjLimpo = cleanNumbers(formData.cnpj);
      if (cnpjLimpo.length < 14) {
        setMessage({ type: 'error', text: '❌ Erro nos dados: CNPJ deve conter 14 dígitos.' });
        setIsSaving(false);
        return;
      }

      // 2. Persistência (LocalStorage é síncrona, zero delay aqui)
      const insertSuccess = db.addClient({
        ...formData,
        cnpj: cnpjLimpo,
        whatsapp: cleanNumbers(formData.whatsapp),
        rbt12_atual: parseFloat(formData.rbt12_atual) || 0,
        id_parceiro_vinculado: currentUser?.id || 'admin'
      });

      if (!insertSuccess) {
        setMessage({ type: 'error', text: '❌ Conflito: Este CNPJ já está cadastrado em nossa base.' });
        setIsSaving(false);
        return;
      }

      // 3. Sucesso Imediato
      setMessage({ type: 'success', text: '✅ CADASTRO REALIZADO COM SUCESSO! Abrindo simulador...' });

      // 4. Thread de E-mail Desvinculada (Sem await para evitar crash por delay de rede)
      enviarAlertaNovoLead(
        currentUser?.nome || 'Operador',
        formData.razao_social,
        0
      ).catch(() => {}); // Falha de e-mail não interrompe o fluxo

      // 5. Transição Controlada (Em vez de reload, usamos a troca de aba do React)
      setTimeout(() => {
        if (onNavigate) {
          onNavigate('sales_simulator');
        } else {
          // Fallback seguro se não houver função de navegação
          setIsSaving(false);
          setFormData({
            cnpj: '', razao_social: '', nome_contato: '', email: '', whatsapp: '',
            uf: 'PA', cidade: '', setor: 'Autopeças', rbt12_atual: '', regime_tributario: RegimeTributario.SIMPLES_COMERCIO
          });
        }
      }, 1000);

    } catch (err: any) {
      console.error("Critical Register Error:", err);
      setMessage({ type: 'error', text: `❌ Falha Técnica: ${err.message || 'Erro de processamento'}` });
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in pb-20">
      <header>
        <h2 className="text-3xl font-black text-slate-900 flex items-center gap-3 tracking-tight uppercase italic">
          <Building2 className="text-blue-600" size={32} /> Registro de Clientes <span className="text-blue-500">Gold</span>
        </h2>
      </header>

      <div className="bg-white rounded-[40px] shadow-2xl border border-slate-100 p-10">
        {message && (
          <div className={`mb-8 p-5 rounded-2xl text-sm font-black border-2 animate-pop-in flex items-center gap-3 ${
            message.type === 'success' ? 'bg-green-50 text-green-700 border-green-200' : 
            'bg-red-50 text-red-700 border-red-200'
          }`}>
            {message.type === 'error' ? <AlertCircle size={20} /> : <CheckCircle2 size={20} />}
            {message.text}
          </div>
        )}

        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
          <div className="col-span-full font-black text-slate-400 flex items-center gap-3 border-b border-slate-50 pb-2 text-[9px] uppercase tracking-[0.2em]">
            <Building2 size={12} className="text-blue-500" /> Identificação Corporativa
          </div>
          
          <div className="space-y-1">
            <label>CNPJ da Empresa</label>
            <input 
              maxLength={18}
              value={formData.cnpj} 
              onChange={e => setFormData({...formData, cnpj: e.target.value})} 
              className="w-full px-4 py-2 border-2 border-slate-50 bg-slate-50 rounded-xl font-bold outline-none focus:border-blue-500 focus:bg-white transition-all text-xs" 
              placeholder="00.000.000/0001-00"
              disabled={isSaving}
              required 
            />
          </div>
          <div className="space-y-1">
            <label>Razão Social</label>
            <input 
              value={formData.razao_social} 
              onChange={e => setFormData({...formData, razao_social: e.target.value})} 
              className="w-full px-4 py-2 border-2 border-slate-50 bg-slate-50 rounded-xl font-bold outline-none focus:border-blue-500 focus:bg-white transition-all text-xs" 
              placeholder="Razão Social"
              disabled={isSaving}
              required 
            />
          </div>

          <div className="col-span-full font-black text-slate-400 flex items-center gap-3 border-b border-slate-50 pb-2 pt-3 text-[9px] uppercase tracking-[0.2em]">
            <UserCircle size={12} className="text-emerald-500" /> Responsável Directo
          </div>
          <div className="space-y-1">
            <label>Nome do Contato</label>
            <input 
              value={formData.nome_contato} 
              onChange={e => setFormData({...formData, nome_contato: e.target.value})} 
              className="w-full px-4 py-2 border-2 border-slate-50 bg-slate-50 rounded-xl font-bold outline-none focus:border-blue-500 focus:bg-white transition-all text-xs" 
              placeholder="Nome completo"
              disabled={isSaving}
              required 
            />
          </div>
          <div className="space-y-1">
            <label>WhatsApp</label>
            <input 
              maxLength={15}
              value={formData.whatsapp} 
              onChange={e => setFormData({...formData, whatsapp: e.target.value})} 
              className="w-full px-4 py-2 border-2 border-slate-50 bg-slate-50 rounded-xl font-bold outline-none focus:border-blue-500 focus:bg-white transition-all text-xs" 
              placeholder="(00) 00000-0000"
              disabled={isSaving}
              required 
            />
          </div>

          <div className="col-span-full font-black text-slate-400 flex items-center gap-3 border-b border-slate-50 pb-2 pt-3 text-[9px] uppercase tracking-[0.2em]">
            <MapPin size={12} className="text-orange-500" /> Sede Social
          </div>
          <div className="space-y-1">
            <label>Setor</label>
            <select 
              value={formData.setor} 
              onChange={e => setFormData({...formData, setor: e.target.value})} 
              className="w-full px-4 py-2 border-2 border-slate-50 bg-slate-50 rounded-xl font-black outline-none focus:border-blue-500 focus:bg-white transition-all text-xs"
              disabled={isSaving}
            >
              {SETORES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="space-y-1">
            <label>Estado</label>
            <select 
              value={formData.uf} 
              onChange={e => setFormData({...formData, uf: e.target.value})} 
              className="w-full px-4 py-2 border-2 border-slate-50 bg-slate-50 rounded-xl font-black outline-none focus:border-blue-500 focus:bg-white transition-all text-xs"
              disabled={isSaving}
            >
              {LISTA_UFS.map(uf => <option key={uf} value={uf}>{uf}</option>)}
            </select>
          </div>
          <div className="space-y-1 md:col-span-2">
            <label>Cidade</label>
            <input 
              value={formData.cidade} 
              onChange={e => setFormData({...formData, cidade: e.target.value})} 
              className="w-full px-4 py-2 border-2 border-slate-50 bg-slate-50 rounded-xl font-bold outline-none focus:border-blue-500 focus:bg-white transition-all text-xs" 
              placeholder="Cidade"
              disabled={isSaving}
              required 
            />
          </div>

          <div className="col-span-full pt-8">
            <button 
              type="submit" 
              disabled={isSaving}
              className="w-full bg-slate-900 text-white font-black py-4 rounded-2xl shadow-xl hover:bg-black transition-all transform active:scale-[0.98] text-sm uppercase tracking-widest flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-wait"
            >
              <Save size={18} /> {isSaving ? 'PROCESSANDO...' : 'Finalizar Cadastro e Abrir Simulador'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
