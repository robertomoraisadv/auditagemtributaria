
import React, { useState, useEffect } from 'react';
import { db } from '../services/db';
import { NCMData } from '../types';
import { Search, Database, Upload, HelpCircle, ChevronDown, ChevronUp, FileText, CheckCircle, AlertCircle, Info, Layers } from 'lucide-react';

export const TechnicalTables: React.FC = () => {
  const [data, setData] = useState<NCMData[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [uploadMessage, setUploadMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const [isHelpOpen, setIsHelpOpen] = useState(true);

  useEffect(() => {
    setData(db.getNCMs());
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        try {
          const lines = text.split('\n');
          const newNcms: NCMData[] = [];
          lines.forEach((line, index) => {
            if (index === 0 || !line.trim()) return;
            const parts = line.split(/[,;]/);
            const ncm = parts[0]?.trim().replace(/\D/g, '');
            const desc = parts[1]?.trim() || 'Sem descrição';
            if (ncm) newNcms.push({ ncm, categoria: 'Importado', descricao: desc });
          });

          if (newNcms.length > 0) {
            db.updateNCMs(newNcms);
            setData(newNcms);
            setUploadMessage({ type: 'success', text: `Base atualizada com ${newNcms.length} produtos!` });
          }
        } catch (error) {
          setUploadMessage({ type: 'error', text: 'Erro ao processar CSV.' });
        }
      }
    };
    reader.readAsText(file);
  };

  const filteredData = data.filter(i => i.ncm.includes(searchTerm) || i.descricao.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="space-y-8 animate-fade-in max-w-6xl mx-auto pb-20">
      <header className="border-b pb-4">
        <h2 className="text-3xl font-black text-slate-900 flex items-center gap-3 tracking-tighter uppercase italic">
          <Database className="text-blue-600" size={32} /> Tabelas Técnicas <span className="text-blue-500">Master</span>
        </h2>
        <p className="text-sm text-slate-500 font-medium italic">Base de conhecimento NCM/Monofásicos do sistema.</p>
      </header>

      {/* SEÇÃO C: TUTORIAL (EXPANDIDO POR PADRÃO) */}
      <div className="bg-blue-600 rounded-[40px] shadow-2xl overflow-hidden border border-blue-500">
        <button onClick={() => setIsHelpOpen(!isHelpOpen)} className="w-full flex items-center justify-between p-8 text-white">
          <div className="flex items-center gap-4">
             <Layers size={28} />
             <h3 className="text-xl font-black uppercase tracking-widest italic">📘 GUIA: Como montar a Tabela Mestre (Passo a Passo)</h3>
          </div>
          {isHelpOpen ? <ChevronUp size={24} /> : <ChevronDown size={24} />}
        </button>
        
        {isHelpOpen && (
          <div className="px-10 pb-10 space-y-8 animate-slide-down text-blue-50">
            <p className="text-sm font-bold leading-relaxed opacity-90">
              Para cobrir 100% dos produtos monofásicos, você deve criar um arquivo Excel único unificando as fontes oficiais:
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white/10 p-6 rounded-3xl border border-white/10">
                <h4 className="font-black text-xs uppercase mb-3 text-white">1. Portal SPED</h4>
                <p className="text-[11px] leading-relaxed">Baixe as Tabelas 4.3.10 (Bebidas/Autopeças) e 4.3.13 (Higiene/Perfumaria) diretamente do Portal SPED.</p>
              </div>
              <div className="bg-white/10 p-6 rounded-3xl border border-white/10">
                <h4 className="font-black text-xs uppercase mb-3 text-white">2. Lista CMED</h4>
                <p className="text-[11px] leading-relaxed">Baixe a lista CMED de medicamentos. Filtre apenas os itens da "Lista Negativa" e "Lista Positiva".</p>
              </div>
              <div className="bg-white/10 p-6 rounded-3xl border border-white/10">
                <h4 className="font-black text-xs uppercase mb-3 text-white">3. Unificação CSV</h4>
                <p className="text-[11px] leading-relaxed">Copie todos os NCMs para uma coluna A e as descrições para a B. Salve como CSV e suba no módulo abaixo.</p>
              </div>
            </div>

            <div className="bg-blue-800/50 p-4 rounded-2xl flex items-center gap-3">
              <AlertCircle size={18} className="text-blue-300" />
              <span className="text-[10px] font-black uppercase tracking-widest">Aviso: O sistema utiliza o código NCM puro (apenas números) para a auditoria.</span>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* SEÇÃO A: CONSULTA */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-[40px] shadow-xl border border-slate-100 overflow-hidden min-h-[500px] flex flex-col">
            <div className="p-6 border-b flex items-center justify-between">
              <div className="flex items-center gap-2">
                 <Search className="text-slate-400" size={18} />
                 <input
                  type="text"
                  placeholder="Pesquisar NCM ou produto..."
                  className="bg-transparent border-none outline-none font-bold text-slate-700 w-64 text-sm"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                <span className="text-[10px] font-black text-slate-400 uppercase">{data.length} Cadastrados</span>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto max-h-[600px]">
              <table className="w-full text-[11px] text-left">
                <thead className="bg-slate-50 text-slate-400 font-black uppercase sticky top-0">
                  <tr>
                    <th className="px-6 py-4">NCM</th>
                    <th className="px-6 py-4">Descrição</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {filteredData.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="px-6 py-4 font-black text-blue-600 text-sm tracking-tighter">{item.ncm}</td>
                      <td className="px-6 py-4 text-slate-600 font-medium uppercase">{item.descricao}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* SEÇÃO B: UPLOAD */}
        <div className="space-y-6">
          <div className="bg-slate-900 rounded-[40px] p-8 shadow-2xl text-white space-y-6">
            <div className="flex items-center gap-3 border-b border-slate-700 pb-4">
              <Upload className="text-blue-400" size={24} />
              <h3 className="font-black text-xs uppercase tracking-widest italic">Atualizar Base de Dados</h3>
            </div>
            
            <p className="text-[10px] text-slate-400 leading-relaxed font-bold uppercase tracking-wider">
              O upload de um novo arquivo substituirá INTEGRALMENTE a base atual de NCMs.
            </p>

            <div className="bg-slate-800 border-2 border-dashed border-slate-700 rounded-3xl p-8 text-center space-y-4 hover:border-blue-500 transition-all">
               <FileText className="mx-auto text-slate-600" size={40} />
               <input type="file" accept=".csv" id="csv-upload" className="hidden" onChange={handleFileUpload} />
               <label htmlFor="csv-upload" className="block w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-4 rounded-2xl cursor-pointer text-[10px] uppercase tracking-widest shadow-xl">
                 Selecionar Novo CSV
               </label>
            </div>

            {uploadMessage && (
              <div className={`p-4 rounded-2xl text-[10px] font-black flex items-center gap-2 ${uploadMessage.type === 'success' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
                {uploadMessage.type === 'success' ? <CheckCircle size={14} /> : <AlertCircle size={14} />}
                {uploadMessage.text}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
