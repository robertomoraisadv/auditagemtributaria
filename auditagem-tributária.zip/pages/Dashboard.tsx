
import React, { useEffect, useState } from 'react';
import { db } from '../services/db';
// Fix: Audit does not exist, use AuditProcess
import { Client, AuditProcess } from '../types';
import { Users, TrendingUp, AlertCircle, CheckCircle, Wallet, Award } from 'lucide-react';

export const Dashboard: React.FC = () => {
  const [clients, setClients] = useState<Client[]>([]);
  // Fix: Audit does not exist, use AuditProcess
  const [audits, setAudits] = useState<AuditProcess[]>([]);

  useEffect(() => {
    setClients(db.getClients(undefined, true));
    // Fix: getAudits does not exist, use getProcesses
    setAudits(db.getProcesses(undefined, true));
  }, []);

  // Fix: Property valor_total_recuperavel does not exist on AuditProcess, use valor_estimado
  const totalPotencial = audits.reduce((acc, curr) => acc + (curr.valor_estimado || 0), 0);
  
  // Métricas ERP
  // Fix: Client does not have valor_honorarios, use audits for this metric
  const totalHonorarios = audits.reduce((acc, curr) => acc + (curr.valor_honorarios || 0), 0);
  // Fix: Client does not have status_processo, count clients from database
  const totalClientesAtivos = clients.length;

  // Ranking Top 3 Parceiros
  const partnerCounts = clients.reduce((acc, client) => {
    // Fix: created_by_user_id does not exist, use id_parceiro_vinculado
    const pid = client.id_parceiro_vinculado || 'unknown';
    acc[pid] = (acc[pid] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const allUsers = db.getUsers();
  // Fixed sorting logic to explicitly cast to number to avoid arithmetic type error on destructuring
  const topPartners = Object.entries(partnerCounts)
    .sort((a, b) => Number(b[1]) - Number(a[1]))
    .slice(0, 3)
    .map(([id, count]) => {
      const u = allUsers.find(user => user.id === id);
      return { name: u ? u.nome : 'Sistema', count };
    });

  const stats = [
    { label: 'Clientes Ativos', value: totalClientesAtivos, icon: Users, color: 'bg-blue-500' },
    { label: 'Potencial Total (Audit)', value: new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }).format(totalPotencial), icon: TrendingUp, color: 'bg-emerald-500' },
    { label: 'Honorários Previstos', value: new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }).format(totalHonorarios), icon: Wallet, color: 'bg-indigo-500' },
    // Fix: Client does not have status_processo, filter audits instead
    { label: 'Finalizados', value: audits.filter(p => p.status_processo === 'Finalizado').length, icon: CheckCircle, color: 'bg-slate-500' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <header>
        <h2 className="text-2xl font-bold text-slate-800">Painel de Controle Gerencial</h2>
        <p className="text-slate-500">Visão consolidada de performance e finanças.</p>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <div key={idx} className="bg-white rounded-xl p-6 shadow-sm border border-slate-100 flex items-center gap-4 hover:shadow-md transition-shadow">
              <div className={`${stat.color} p-3 rounded-lg text-white`}>
                <Icon size={24} />
              </div>
              <div>
                <p className="text-xs font-bold uppercase text-slate-400">{stat.label}</p>
                <p className="text-xl font-bold text-slate-800">{stat.value}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Clients Table */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center">
            <h3 className="font-semibold text-slate-800">Clientes Recentes</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-slate-50 text-slate-600 font-medium border-b border-slate-200">
                <tr>
                  <th className="px-6 py-3">Razão Social</th>
                  <th className="px-6 py-3">Status</th>
                  <th className="px-6 py-3">Data</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {clients.slice(-5).reverse().map((client) => {
                  // Fix: Lookup status from the latest process for this client
                  const latestProcess = audits.filter(p => p.id_cliente === client.id).sort((a,b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];
                  const status = latestProcess ? latestProcess.status_processo : 'Prospecção';
                  return (
                    <tr key={client.id} className="hover:bg-slate-50">
                      <td className="px-6 py-3 font-medium text-slate-700">{client.razao_social}</td>
                      <td className="px-6 py-3">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                          status === 'Finalizado' ? 'bg-green-100 text-green-700' :
                          status === 'Em Análise' ? 'bg-blue-100 text-blue-700' :
                          'bg-slate-100 text-slate-600'
                        }`}>
                           {status}
                        </span>
                      </td>
                      <td className="px-6 py-3 text-slate-500">
                        {new Date(client.data_cadastro).toLocaleDateString('pt-BR')}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Ranking Parceiros */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6">
           <h3 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
             <Award className="text-amber-500" /> Top Parceiros
           </h3>
           <div className="space-y-4">
             {topPartners.length > 0 ? topPartners.map((p, idx) => (
               <div key={idx} className="flex items-center justify-between border-b border-slate-50 last:border-0 pb-2 last:pb-0">
                 <div className="flex items-center gap-3">
                   <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                     idx === 0 ? 'bg-amber-100 text-amber-700' : 
                     idx === 1 ? 'bg-slate-200 text-slate-600' : 
                     'bg-orange-100 text-orange-700'
                   }`}>
                     #{idx + 1}
                   </div>
                   <span className="font-medium text-slate-700">{p.name}</span>
                 </div>
                 <span className="text-sm font-bold text-slate-500">{p.count} leads</span>
               </div>
             )) : (
               <p className="text-slate-400 text-sm">Nenhum dado de performance ainda.</p>
             )}
           </div>
        </div>
      </div>
    </div>
  );
};
