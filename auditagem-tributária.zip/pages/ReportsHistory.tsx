
import React, { useEffect, useState } from 'react';
import { db } from '../services/db';
// Fix: Audit does not exist, use AuditProcess
import { AuditProcess, Client, User } from '../types';
import { FileText, Calendar, DollarSign, User as UserIcon } from 'lucide-react';

interface Props {
  currentUser?: User;
}

export const ReportsHistory: React.FC<Props> = ({ currentUser }) => {
  // Fix: Audit does not exist, use AuditProcess
  const [audits, setAudits] = useState<AuditProcess[]>([]);
  const [clients, setClients] = useState<Client[]>([]);

  useEffect(() => {
    // Fix: getAudits does not exist, use getProcesses
    setAudits(db.getProcesses(currentUser?.id, currentUser?.funcao === 'admin').reverse());
    setClients(db.getClients(currentUser?.id, currentUser?.funcao === 'admin'));
  }, [currentUser]);

  // Fix: Audit type changed to AuditProcess and property mapping updated
  const getClientName = (audit: AuditProcess) => {
    if (audit.id_cliente.startsWith('PROSPECT')) {
      // Logic for prospect name recovery from log
      const match = audit.log_auditoria.match(/Simulação Comercial: (.*?) -/);
      return match ? match[1] : 'Prospect Desconhecido';
    }
    const client = clients.find(c => c.id === audit.id_cliente);
    return client ? client.razao_social : 'Cliente Removido';
  };

  const fmtBRL = (val: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  return (
    <div className="space-y-6 animate-fade-in">
      <header>
        <h2 className="text-2xl font-bold text-slate-800">Histórico de Relatórios</h2>
        <p className="text-slate-500">
          {currentUser?.funcao === 'admin' 
            ? 'Registro completo de todas as auditorias e simulações do sistema.' 
            : 'Registro das suas simulações comerciais.'}
        </p>
      </header>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        {audits.length === 0 ? (
          <div className="p-12 text-center text-slate-500">
            <FileText size={48} className="mx-auto mb-4 opacity-30" />
            <p>Nenhuma auditoria ou simulação registrada no histórico.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                <tr>
                  <th className="px-6 py-4">Data</th>
                  <th className="px-6 py-4">Cliente / Prospect</th>
                  <th className="px-6 py-4">Tipo</th>
                  <th className="px-6 py-4">Valor Identificado</th>
                  <th className="px-6 py-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {audits.map((audit) => (
                  <tr key={audit.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 text-slate-500 flex items-center gap-2">
                      <Calendar size={14} />
                      {/* Fix: data_processamento -> created_at */}
                      {new Date(audit.created_at).toLocaleDateString('pt-BR')}
                    </td>
                    <td className="px-6 py-4 font-medium text-slate-800">
                      <div className="flex items-center gap-2">
                         <UserIcon size={14} className="text-slate-400" />
                         {getClientName(audit)}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {/* Fix: tipo -> tipo_origem */}
                      {audit.tipo_origem === 'SIMULACAO' ? (
                        <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-amber-100 text-amber-800">
                          Simulação Comercial
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-blue-100 text-blue-800">
                          Auditoria Fiscal (XML)
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 font-bold text-emerald-600">
                      {/* Fix: valor_total_recuperavel -> valor_estimado */}
                      {fmtBRL(audit.valor_estimado)}
                    </td>
                    <td className="px-6 py-4 text-slate-500 text-xs uppercase tracking-wide">
                      {/* Fix: status -> status_processo */}
                      {audit.status_processo}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
