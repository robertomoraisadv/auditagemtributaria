
import React, { useState } from 'react';
import { db } from '../services/db';
import { User } from '../types';
import { ShieldCheck, Lock, Mail, AlertOctagon, ArrowRight } from 'lucide-react';

interface LoginProps {
  onLoginSuccess: (user: User) => void;
}

export const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // UX: Simula processamento para dar feedback visual de segurança
    setTimeout(() => {
      const result = db.authenticate(email, password);
      
      if (result.user) {
        onLoginSuccess(result.user);
      } else {
        setError(result.error || 'Credenciais inválidas.');
        setLoading(false);
      }
    }, 700);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden animate-fade-in border border-slate-700">
        <div className="bg-slate-900 p-8 text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-indigo-600"></div>
          <div className="mx-auto w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center mb-4 border border-blue-500/20">
            <ShieldCheck size={40} className="text-blue-500" />
          </div>
          <h1 className="text-2xl font-bold text-white tracking-wide">Auditagem<span className="text-blue-500">TributárIA</span></h1>
          <p className="text-slate-400 text-[10px] mt-2 font-mono uppercase tracking-[0.2em]">Build v6.7 &bull; Security Compliance</p>
        </div>

        <div className="p-8">
          {error && (
            <div className={`mb-6 p-4 border text-sm rounded-xl flex items-start gap-3 animate-shake ${
              error.includes('SUSPENSO') 
                ? 'bg-red-950/20 border-red-500 text-red-500 font-bold' 
                : 'bg-amber-50 border-amber-200 text-amber-700'
            }`}>
              <AlertOctagon size={20} className="shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Email Corporativo</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail size={18} className="text-slate-300" />
                </div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl focus:border-blue-500 focus:ring-4 focus:ring-blue-50/50 outline-none transition-all text-slate-800 placeholder-slate-300"
                  placeholder="seu@email.com"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Chave de Segurança</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock size={18} className="text-slate-300" />
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl focus:border-blue-500 focus:ring-4 focus:ring-blue-50/50 outline-none transition-all text-slate-800 placeholder-slate-300"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className={`w-full flex items-center justify-center gap-2 bg-slate-900 hover:bg-black text-white font-bold py-4 rounded-xl shadow-xl transition-all transform active:scale-[0.98] mt-4 ${loading ? 'opacity-70 cursor-wait' : ''}`}
            >
              {loading ? 'Validando Integridade...' : <><span className="mr-2">Acessar Plataforma</span> <ArrowRight size={18} /></>}
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-slate-50 text-center text-[10px] text-slate-300 font-medium uppercase tracking-widest">
            &copy; 2024 Auditagem TributárIA &bull; IA-POWERED COMPLIANCE
          </div>
        </div>
      </div>
    </div>
  );
};
