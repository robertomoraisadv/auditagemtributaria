
import React, { useState, useEffect } from 'react';
import { db } from '../services/db';
import { Client, User } from '../types';
import { generateSimulationReport, generateAnalyticReport } from '../services/pdfGenerator';
import { getEstimatedTaxRate, gerarAuditoriaSimulada } from '../services/auditCore';
import { Calculator, Download, Save, CheckCircle2, TrendingUp, FileText, Settings } from 'lucide-react';

interface Props {
  currentUser?: User;
}

export const SalesSimulator: React.FC<Props> = ({ currentUser }) => {
  const [clients, setClients] = useState<Client[]>([]);
  const [selectedClientId, setSelectedClientId] = useState('');
  const [faturamentoMensal, setFaturamentoMensal] = useState<number>(0);
  const [percentualMonofasico, setPercentualMonofasico] = useState<number>(0.25);
  const [meses, setMeses] = useState<number>(60);
  const [result, setResult] = useState<number | null>(null);
  const [appliedRate, setAppliedRate] = useState<number>(0); 
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setClients(db.getClients(currentUser?.id, currentUser?.funcao === 'admin'));
  }, [currentUser]);

  const calculate = () => {
    const aliquota = getEstimatedTaxRate(faturamentoMensal);
    setAppliedRate(aliquota);
    const baseCalculo = faturamentoMensal * percentualMonofasico;
    const totalRecuperavel = baseCalculo * meses * aliquota; 
    setResult(totalRecuperavel);
    setSaved(false);
  };

  const handleSave = () => {
    if (result === null || !selectedClientId) return;
    db.saveAuditProcess({
      id_cliente: selectedClientId,
      id_parceiro: currentUser?.id || 'admin',
      periodo_inicio: 'Últimos 60 Meses',
      periodo_fim: 'Atual',
      status_processo: 'Prospecção',
      valor_estimado: result,
      pct_honorarios: 30,
      status_pgto_cliente: 'A Faturar',
      tipo_origem: 'SIMULACAO',
      log_auditoria: `Simulação Comercial: ${faturamentoMensal} mensal / ${(percentualMonofasico*100).toFixed(0)}% Mono`
    });
    setSaved(true);
  };

  const fmtBRL = (val: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  return (
    <div className="space-y-8 animate-fade-in max-w-6xl mx-auto pb-20">
      <header className="border-b pb-4">
        <h2 className="text-3xl font-black text-slate-900 flex items-center gap-3 tracking-tighter uppercase italic">
          <Calculator className="text-blue-600" size={32} /> Simulador de Potencial <span className="text-blue-500">Gold Master</span>
        </h2>
        <p className="text-sm text-slate-500 font-medium italic">Diagnóstico rápido de créditos monofásicos.</p>
      </header>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 bg-white rounded-3xl shadow-xl border border-slate-100 p-8 space-y-6">
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Selecionar Cliente</label>
            <select value={selectedClientId} onChange={e => setSelectedClientId(e.target.value)} className="w-full px-5 py-3.5 border-2 border-slate-50 rounded-2xl bg-slate-50 outline-none focus:ring-4 focus:ring-blue-100 transition-all font-bold text-slate-700">
              <option value="">-- Escolha um Lead --</option>
              {clients.map(c => <option key={c.id} value={c.id}>{c.razao_social}</option>)}
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Faturamento Médio Mensal (R$)</label>
            <input type="number" step="0.01" value={faturamentoMensal || ''} onChange={e => setFaturamentoMensal(parseFloat(e.target.value))} className="w-full px-5 py-4 border-2 border-slate-100 rounded-2xl font-black text-blue-600 text-2xl outline-none" />
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">% Monofásicos</label>
              <span className="text-xl font-black text-blue-600">{(percentualMonofasico * 100).toFixed(0)}%</span>
            </div>
            <input type="range" min="0" max="1" step="0.01" value={percentualMonofasico} onChange={e => setPercentualMonofasico(parseFloat(e.target.value))} className="w-full h-3 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-600" />
          </div>

          <button onClick={calculate} className="w-full bg-blue-600 text-white font-black py-5 rounded-3xl shadow-2xl hover:bg-blue-700 transition-all uppercase text-lg tracking-wider">
            Executar Diagnóstico
          </button>
        </div>

        <div className="lg:col-span-2 space-y-8">
          {result !== null ? (
            <div className="space-y-6 animate-slide-up">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-8 rounded-[32px] border shadow-sm">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">Alíquota Aplicada</span>
                  <div className="text-3xl font-black text-slate-800">{(appliedRate * 100).toFixed(2)}%</div>
                </div>
                <div className="bg-emerald-500 p-8 rounded-[32px] text-white shadow-2xl">
                  <span className="text-[10px] font-black text-white/70 uppercase tracking-widest block mb-2">Recuperação Total Estimada</span>
                  <div className="text-4xl font-black">{fmtBRL(result)}</div>
                </div>
              </div>

              <div className="bg-slate-900 rounded-[32px] p-10 space-y-8">
                <div className="flex items-center gap-4 border-b border-slate-800 pb-6">
                   <div className="bg-blue-500/20 p-4 rounded-full text-blue-400"><TrendingUp size={32} /></div>
                   <h4 className="text-xl font-black text-white uppercase italic">Central de Emissão de Laudos</h4>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <button onClick={() => generateSimulationReport(clients.find(c => c.id === selectedClientId)?.razao_social || 'Prospect', faturamentoMensal, meses, percentualMonofasico, '', appliedRate)} className="flex items-center justify-center gap-3 bg-white text-slate-900 font-black py-4 rounded-2xl hover:bg-slate-100 transition-all text-xs uppercase tracking-widest">
                    <Download size={18} /> 📄 Laudo Executivo (Cliente)
                  </button>
                  <button onClick={() => {
                    const mockSummary = gerarAuditoriaSimulada(faturamentoMensal, percentualMonofasico * 100);
                    generateAnalyticReport({ razao_social: clients.find(c => c.id === selectedClientId)?.razao_social || 'Prospect' }, mockSummary);
                  }} className="flex items-center justify-center gap-3 bg-blue-600 text-white font-black py-4 rounded-2xl hover:bg-blue-700 transition-all text-xs uppercase tracking-widest">
                    <Settings size={18} /> 🛠️ Laudo Técnico (Contador)
                  </button>
                </div>

                <button onClick={handleSave} disabled={saved || !selectedClientId} className={`w-full py-4 rounded-2xl font-black border-2 transition-all uppercase text-xs tracking-widest ${saved ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-slate-700 text-slate-400 hover:text-white hover:border-white'}`}>
                  {saved ? '✅ PROCESSO PROTOCOLADO' : 'CRIAR PROCESSO NO BACKOFFICE'}
                </button>
              </div>
            </div>
          ) : (
            <div className="h-full border-4 border-dashed border-slate-200 rounded-[40px] flex flex-col items-center justify-center text-slate-300 p-16 bg-white/50">
              <Calculator size={100} className="mb-8 opacity-5" />
              <p className="font-black text-sm text-center uppercase tracking-[0.5em] text-slate-400">Aguardando Parâmetros</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
