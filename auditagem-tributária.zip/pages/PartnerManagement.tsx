
import React, { useState, useEffect } from 'react';
import { db, LISTA_UFS } from '../services/db';
import { User, Role, Sexo } from '../types';
import { 
  Users, Save, Trash2, Search, Mail, Phone, Lock, Unlock, 
  MapPin, Key, UserCheck, Briefcase, CreditCard, ChevronRight
} from 'lucide-react';

export const PartnerManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'LIST' | 'CREATE'>('LIST');
  const [users, setUsers] = useState<User[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [editingUser, setEditingUser] = useState<Partial<User>>({});
  const [newPassword, setNewPassword] = useState('');
  
  const [formData, setFormData] = useState({
    nome: '', email: '', senha_hash: '', funcao: 'parceiro' as Role,
    cpf: '', sexo: 'M' as Sexo, whatsapp: '', chave_pix: '',
    cep: '', logradouro: '', numero: '', bairro: '', 
    uf: 'SP', cidade: '', comissao_percentual: 10
  });

  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => setUsers(db.getUsers());

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (db.addUser(formData)) {
      setMessage({ type: 'success', text: '✅ Parceiro registrado na rede Gold!' });
      setFormData({
        nome: '', email: '', senha_hash: '', funcao: 'parceiro',
        cpf: '', sexo: 'M', whatsapp: '', chave_pix: '', cep: '', logradouro: '', numero: '', bairro: '', 
        uf: 'SP', cidade: '', comissao_percentual: 10
      });
      refreshData();
      setActiveTab('LIST');
    } else {
      setMessage({ type: 'error', text: 'E-mail já cadastrado no sistema.' });
    }
  };

  const handleSaveEdit = () => {
    if (!selectedUserId) return;
    const updates = { ...editingUser };
    if (newPassword.trim()) updates.senha_hash = newPassword;
    
    if (db.updateUser(selectedUserId, updates)) {
      setMessage({ type: 'success', text: 'Dados atualizados com sucesso!' });
      setNewPassword('');
      refreshData();
    }
  };

  const toggleBlock = () => {
    const newStatus = !editingUser.bloqueado;
    db.updateUser(selectedUserId, { bloqueado: newStatus });
    setEditingUser(prev => ({ ...prev, bloqueado: newStatus }));
    refreshData();
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-20">
      <header className="flex justify-between items-center border-b pb-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tighter uppercase italic flex items-center gap-3">
            <Users className="text-blue-600" size={32} /> Gestão de Parceiros <span className="text-blue-500">Gold</span>
          </h2>
          <p className="text-sm text-slate-500 font-medium italic">Controle total sobre a rede de expansão comercial.</p>
        </div>
      </header>

      {message && (
        <div className={`p-5 rounded-2xl text-sm font-black border-2 animate-fade-in ${message.type === 'success' ? 'bg-green-50 text-green-700 border-green-200' : 'bg-red-50 text-red-700 border-red-200'}`}>
          {message.text}
        </div>
      )}

      <div className="flex bg-slate-200 p-2 rounded-[24px] w-fit shadow-inner">
        <button onClick={() => setActiveTab('LIST')} className={`px-10 py-3 text-xs font-black rounded-[18px] transition-all uppercase tracking-widest ${activeTab === 'LIST' ? 'bg-white text-blue-600 shadow-xl' : 'text-slate-500 hover:text-slate-700'}`}>GERENCIAR</button>
        <button onClick={() => setActiveTab('CREATE')} className={`px-10 py-3 text-xs font-black rounded-[18px] transition-all uppercase tracking-widest ${activeTab === 'CREATE' ? 'bg-white text-blue-600 shadow-xl' : 'text-slate-500 hover:text-slate-700'}`}>NOVO CADASTRO</button>
      </div>

      {activeTab === 'LIST' && (
        <div className="bg-white p-10 rounded-[40px] border shadow-2xl space-y-10 animate-fade-in">
          <div className="max-w-md">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Membro da Rede</label>
            <select value={selectedUserId} onChange={e => {
              const id = e.target.value;
              setSelectedUserId(id);
              const u = users.find(x => x.id === id);
              if (u) setEditingUser({ ...u });
            }} className="w-full mt-1 border-2 border-slate-50 rounded-2xl py-4 px-6 outline-none bg-slate-50 focus:ring-4 focus:ring-blue-100 transition-all font-bold text-slate-700">
              <option value="">-- Escolha um Parceiro --</option>
              {users.map(u => <option key={u.id} value={u.id}>{u.nome} ({u.email}) {u.bloqueado ? ' [BLOQUEADO]' : ''}</option>)}
            </select>
          </div>

          {selectedUserId && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-10 pt-10 border-t border-slate-100 animate-slide-up">
              <div className="col-span-full font-black text-slate-800 flex items-center gap-2 mb-2 uppercase tracking-tighter text-xl"><UserCheck size={24} className="text-blue-500" /> DADOS CADASTRAIS & REMUNERAÇÃO</div>
              
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Nome Completo</label>
                <input value={editingUser.nome} onChange={e => setEditingUser({...editingUser, nome: e.target.value})} className="w-full px-5 py-3.5 border-2 border-slate-50 rounded-2xl font-bold bg-slate-50 focus:bg-white transition-all" />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">WhatsApp (Max: 15)</label>
                <input 
                  maxLength={15}
                  value={editingUser.whatsapp} 
                  onChange={e => setEditingUser({...editingUser, whatsapp: e.target.value})} 
                  className="w-full px-5 py-3.5 border-2 border-slate-50 rounded-2xl font-bold bg-slate-50 focus:bg-white transition-all" 
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Chave PIX</label>
                <input value={editingUser.chave_pix} onChange={e => setEditingUser({...editingUser, chave_pix: e.target.value})} className="w-full px-5 py-3.5 border-2 border-slate-50 rounded-2xl font-bold bg-slate-50 focus:bg-white transition-all" />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">% Comissão</label>
                <input type="number" value={editingUser.comissao_percentual} onChange={e => setEditingUser({...editingUser, comissao_percentual: parseFloat(e.target.value)})} className="w-full px-5 py-3.5 border-2 border-slate-100 rounded-2xl font-black text-blue-600 bg-white" />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Nova Senha (Opcional)</label>
                <input type="text" placeholder="Vazio p/ manter" value={newPassword} onChange={e => setNewPassword(e.target.value)} className="w-full px-5 py-3.5 border-2 border-blue-50 rounded-2xl bg-blue-50/20 font-bold" />
              </div>

              <div className="col-span-full pt-10 flex flex-wrap gap-4 border-t border-slate-50">
                <button onClick={handleSaveEdit} className="bg-slate-900 text-white px-12 py-4 rounded-[20px] font-black flex items-center gap-3 shadow-2xl hover:bg-black transition-all transform active:scale-95 uppercase tracking-widest"><Save size={20} /> ATUALIZAR PARCEIRO</button>
                <button onClick={toggleBlock} className={`px-10 py-4 rounded-[20px] font-black border-4 transition-all transform active:scale-95 uppercase tracking-widest ${editingUser.bloqueado ? 'border-green-600 text-green-600 bg-green-50' : 'border-red-600 text-red-600 bg-red-50'}`}>
                  {editingUser.bloqueado ? <Unlock size={20} className="inline mr-3" /> : <Lock size={20} className="inline mr-3" />} {editingUser.bloqueado ? 'DESBLOQUEAR ACESSO' : 'BLOQUEAR ACESSO'}
                </button>
                {editingUser.id !== 'admin-v11-gold' && (
                  <button onClick={() => { if(confirm('⚠️ Deletar este parceiro permanentemente?')) { db.deleteUser(selectedUserId); setSelectedUserId(''); refreshData(); }}} className="bg-slate-50 text-slate-400 hover:text-red-600 px-6 py-4 rounded-[20px] font-black transition-all"><Trash2 size={24} /></button>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'CREATE' && (
        <form onSubmit={handleCreateSubmit} className="bg-white p-12 rounded-[40px] border shadow-2xl animate-fade-in space-y-12">
           <div className="grid grid-cols-1 md:grid-cols-4 gap-x-8 gap-y-10">
              <div className="col-span-full font-black text-slate-800 flex items-center gap-3 border-b-2 border-slate-50 pb-4 text-xl tracking-tighter uppercase italic"><Briefcase size={24} className="text-blue-500" /> CADASTRO PESSOAL & ACESSO</div>
              
              <div className="md:col-span-2 space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Nome Completo</label>
                <input value={formData.nome} onChange={e => setFormData({...formData, nome: e.target.value})} className="w-full px-5 py-4 border-2 border-slate-100 bg-slate-50 rounded-[22px] font-bold outline-none focus:bg-white focus:border-blue-500 transition-all" required />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">CPF (Max: 14)</label>
                <input 
                  maxLength={14}
                  value={formData.cpf} 
                  onChange={e => setFormData({...formData, cpf: e.target.value})} 
                  className="w-full px-5 py-4 border-2 border-slate-100 bg-slate-50 rounded-[22px] font-bold outline-none focus:bg-white focus:border-blue-500 transition-all" 
                  placeholder="000.000.000-00"
                  required 
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Sexo</label>
                <div className="flex gap-6 pt-3">
                  <label className="flex items-center gap-2 cursor-pointer font-black text-slate-600"><input type="radio" name="sexo" value="M" checked={formData.sexo === 'M'} onChange={e => setFormData({...formData, sexo: 'M'})} /> M</label>
                  <label className="flex items-center gap-2 cursor-pointer font-black text-slate-600"><input type="radio" name="sexo" value="F" checked={formData.sexo === 'F'} onChange={e => setFormData({...formData, sexo: 'F'})} /> F</label>
                </div>
              </div>
              <div className="md:col-span-2 space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">E-mail Corporativo</label>
                <input type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full px-5 py-4 border-2 border-slate-100 bg-slate-50 rounded-[22px] font-bold outline-none focus:bg-white focus:border-blue-500 transition-all" required />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Senha Inicial</label>
                <input type="password" value={formData.senha_hash} onChange={e => setFormData({...formData, senha_hash: e.target.value})} className="w-full px-5 py-4 border-2 border-slate-100 bg-slate-50 rounded-[22px] font-bold outline-none focus:bg-white focus:border-blue-500 transition-all" required />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">WhatsApp (Max: 15)</label>
                <input 
                  maxLength={15}
                  value={formData.whatsapp} 
                  onChange={e => setFormData({...formData, whatsapp: e.target.value})} 
                  className="w-full px-5 py-4 border-2 border-slate-100 bg-slate-50 rounded-[22px] font-bold outline-none focus:bg-white focus:border-blue-500 transition-all" 
                  placeholder="(00) 00000-0000"
                  required 
                />
              </div>

              <div className="col-span-full font-black text-slate-800 flex items-center gap-3 border-b-2 border-slate-50 pb-4 pt-6 text-xl tracking-tighter uppercase italic"><MapPin size={24} className="text-orange-500" /> ENDEREÇO & DADOS BANCÁRIOS</div>
              
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">CEP (Max: 9)</label>
                <input 
                  maxLength={9}
                  value={formData.cep} 
                  onChange={e => setFormData({...formData, cep: e.target.value})} 
                  className="w-full px-5 py-4 border-2 border-slate-100 bg-slate-50 rounded-[22px] font-bold outline-none focus:bg-white focus:border-blue-500 transition-all" 
                  placeholder="00000-000"
                />
              </div>
              <div className="md:col-span-2 space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Logradouro / Avenida</label>
                <input value={formData.logradouro} onChange={e => setFormData({...formData, logradouro: e.target.value})} className="w-full px-5 py-4 border-2 border-slate-100 bg-slate-50 rounded-[22px] font-bold outline-none focus:bg-white focus:border-blue-500 transition-all" />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Número</label>
                <input value={formData.numero} onChange={e => setFormData({...formData, numero: e.target.value})} className="w-full px-5 py-4 border-2 border-slate-100 bg-slate-50 rounded-[22px] font-bold outline-none focus:bg-white focus:border-blue-500 transition-all" />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Bairro</label>
                <input value={formData.bairro} onChange={e => setFormData({...formData, bairro: e.target.value})} className="w-full px-5 py-4 border-2 border-slate-100 bg-slate-50 rounded-[22px] font-bold outline-none focus:bg-white focus:border-blue-500 transition-all" />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Cidade</label>
                <input value={formData.cidade} onChange={e => setFormData({...formData, cidade: e.target.value})} className="w-full px-5 py-4 border-2 border-slate-100 bg-slate-50 rounded-[22px] font-bold outline-none focus:bg-white focus:border-blue-500 transition-all" />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">UF</label>
                <select value={formData.uf} onChange={e => setFormData({...formData, uf: e.target.value})} className="w-full px-5 py-4 border-2 border-slate-100 bg-slate-50 rounded-[22px] font-black outline-none focus:bg-white focus:border-blue-500 transition-all">
                   {LISTA_UFS.map(uf => <option key={uf} value={uf}>{uf}</option>)}
                </select>
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">% Comissão</label>
                <input type="number" value={formData.comissao_percentual} onChange={e => setFormData({...formData, comissao_percentual: parseFloat(e.target.value)})} className="w-full px-5 py-4 border-2 border-slate-100 bg-slate-50 rounded-[22px] font-black text-blue-600 outline-none focus:bg-white focus:border-blue-500 transition-all" />
              </div>
              <div className="col-span-full md:col-span-2 space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Chave PIX (Para Pagamentos)</label>
                <div className="relative">
                  <CreditCard size={20} className="absolute left-5 top-5 text-slate-300" />
                  <input value={formData.chave_pix} onChange={e => setFormData({...formData, chave_pix: e.target.value})} className="w-full pl-14 pr-5 py-4 border-2 border-slate-100 bg-slate-50 rounded-[22px] font-bold outline-none focus:bg-white focus:border-blue-500 transition-all" placeholder="CPF, E-mail ou Celular" />
                </div>
              </div>
           </div>
           
           <div className="pt-10 border-t-2 border-slate-50 flex justify-end">
             <button type="submit" className="bg-blue-600 text-white font-black py-6 px-20 rounded-[30px] shadow-2xl hover:bg-blue-700 transition-all transform active:scale-95 text-xl uppercase tracking-widest flex items-center gap-3">
               CADASTRAR MEMBRO GOLD <ChevronRight size={24} />
             </button>
           </div>
        </form>
      )}
    </div>
  );
};
