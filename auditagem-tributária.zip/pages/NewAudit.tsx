
import React, { useState, useEffect } from 'react';
import { db } from '../services/db';
import { processarXMLs, gerarAuditoriaSimulada, getEstimatedTaxRate } from '../services/auditCore';
import { generateExecutiveReport, generateAnalyticReport } from '../services/pdfGenerator';
import { Client, MonthlyResult, AuditItem, User } from '../types';
import { UploadCloud, FileText, Save, Lock, FileSearch, Zap, Database, Settings } from 'lucide-react';

interface Props { currentUser?: User; }

export const NewAudit: React.FC<Props> = ({ currentUser }) => {
  const [clients, setClients] = useState<Client[]>([]);
  const [selectedClientId, setSelectedClientId] = useState<string>('');
  const [auditMode, setAuditMode] = useState<'SIMULATION' | 'XML'>('SIMULATION');
  const [files, setFiles] = useState<FileList | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [results, setResults] = useState<{ items?: AuditItem[], summary: MonthlyResult[] } | null>(null);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const [simFat, setSimFat] = useState<number>(50000);
  const [simPct, setSimPct] = useState<number>(30);

  useEffect(() => {
    setClients(db.getClients(undefined, true));
  }, []);

  if (currentUser?.funcao !== 'admin') {
    return <div className="p-20 text-center font-black uppercase italic text-slate-400"><Lock size={64} className="mx-auto mb-4 opacity-10" /> Acesso Admin Requerido</div>;
  }

  const handleProcessXML = async () => {
    if (!files || files.length === 0 || !selectedClientId) return;
    setIsProcessing(true);
    const data = await processarXMLs(files);
    setResults(data);
    setIsProcessing(false);
  };

  const handleRunSimulation = () => {
    if (!selectedClientId) return;
    setIsProcessing(true);
    setTimeout(() => {
      const summary = gerarAuditoriaSimulada(simFat, simPct);
      setResults({ summary });
      setIsProcessing(false);
    }, 800);
  };

  const handleSaveProcess = () => {
    if (!results || !selectedClientId) return;
    const client = clients.find(c => c.id === selectedClientId);
    const totalRec = results.summary.reduce((acc, curr) => acc + (curr.baseMonofasica * getEstimatedTaxRate(curr.receitaBruta)), 0);
    
    db.saveAuditProcess({
      id_cliente: selectedClientId,
      id_parceiro: client?.id_parceiro_vinculado || 'admin',
      periodo_inicio: results.summary[0]?.competencia,
      periodo_fim: results.summary[results.summary.length-1]?.competencia,
      status_processo: 'Em Análise',
      valor_estimado: totalRec,
      pct_honorarios: 30,
      status_pgto_cliente: 'A Faturar',
      tipo_origem: auditMode === 'XML' ? 'XML' : 'SIMULACAO',
      log_auditoria: `Auditoria Técnica: R$ ${simFat} Fat / ${simPct}%`
    });
    setMessage({ type: 'success', text: 'Protocolo de Auditoria atualizado!' });
    setTimeout(() => setMessage(null), 3000);
  };

  const totalRecuperavel = results?.summary.reduce((acc, curr) => acc + (curr.baseMonofasica * getEstimatedTaxRate(curr.receitaBruta)), 0) || 0;

  return (
    <div className="space-y-6 animate-fade-in pb-20">
      <header className="border-b pb-4">
        <h2 className="text-3xl font-black text-slate-900 flex items-center gap-3 tracking-tighter uppercase italic">
          <FileSearch className="text-blue-600" size={32} /> Auditoria Técnica <span className="text-blue-500">Backoffice</span>
        </h2>
      </header>

      <div className="bg-white rounded-[40px] shadow-2xl border p-10 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <div className="space-y-4">
            <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest ml-1">Fonte</label>
            <div className="flex bg-slate-100 p-1.5 rounded-[22px]">
              <button onClick={() => setAuditMode('SIMULATION')} className={`flex-1 py-3 rounded-[18px] text-[10px] font-black uppercase tracking-wider ${auditMode === 'SIMULATION' ? 'bg-white text-blue-600 shadow-xl' : 'text-slate-500'}`}>Massa Técnica</button>
              <button onClick={() => setAuditMode('XML')} className={`flex-1 py-3 rounded-[18px] text-[10px] font-black uppercase tracking-wider ${auditMode === 'XML' ? 'bg-white text-blue-600 shadow-xl' : 'text-slate-500'}`}>Lote XML</button>
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest ml-1">Vincular Cliente</label>
            <select value={selectedClientId} onChange={e => setSelectedClientId(e.target.value)} className="w-full px-5 py-3 border-2 border-slate-50 rounded-2xl bg-slate-50 outline-none focus:ring-4 focus:ring-blue-100 font-bold text-xs">
               <option value="">-- Selecione na Carteira --</option>
               {clients.map(c => <option key={c.id} value={c.id}>{c.razao_social}</option>)}
            </select>
          </div>
        </div>

        {auditMode === 'XML' ? (
          <div className="bg-blue-50 border-2 border-dashed border-blue-200 rounded-[30px] p-10 text-center space-y-4">
             <UploadCloud className="mx-auto text-blue-400" size={48} />
             <input type="file" multiple accept=".xml" onChange={e => setFiles(e.target.files)} className="mx-auto block text-xs font-bold text-slate-500 file:bg-blue-600 file:text-white file:border-0 file:px-4 file:py-2 file:rounded-xl" />
             <button onClick={handleProcessXML} className="bg-blue-600 text-white font-black py-4 px-12 rounded-2xl shadow-xl uppercase text-xs tracking-widest">Processar Arquivos</button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 bg-slate-50 rounded-[30px] p-8 border">
             <div className="space-y-2">
               <label className="text-[10px] font-black text-slate-400 uppercase">Fat. Médio</label>
               <input type="number" value={simFat} onChange={e => setSimFat(parseFloat(e.target.value))} className="w-full px-5 py-3 border-2 border-slate-200 rounded-2xl font-black text-blue-600 outline-none" />
             </div>
             <div className="space-y-2">
               <label className="text-[10px] font-black text-slate-400 uppercase">Peso Mono ({simPct}%)</label>
               <input type="range" min="0" max="100" value={simPct} onChange={e => setSimPct(parseInt(e.target.value))} className="w-full h-2 bg-slate-200 rounded-lg accent-blue-600 mt-4" />
             </div>
             <div className="flex items-end">
               <button onClick={handleRunSimulation} className="w-full bg-slate-900 text-white font-black py-4 rounded-2xl shadow-xl uppercase text-[10px]">Gerar Auditoria Técnica</button>
             </div>
          </div>
        )}
      </div>

      {results && (
        <div className="animate-slide-up space-y-6">
          <div className="bg-emerald-500 p-8 rounded-[40px] text-white shadow-2xl text-center">
            <span className="text-[10px] font-black text-white/70 uppercase tracking-widest block mb-1">Crédito Técnico Identificado</span>
            <div className="text-4xl font-black">{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totalRecuperavel)}</div>
          </div>

          <div className="bg-white p-8 rounded-[40px] border shadow-xl space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <h3 className="text-xs font-black text-slate-800 uppercase italic">Central de Emissões Gold</h3>
              <div className="flex flex-wrap gap-4">
                 <button onClick={() => generateExecutiveReport(clients.find(c => c.id === selectedClientId)!, results.summary)} className="flex items-center gap-2 bg-slate-900 text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-wider"><FileText size={14} /> Laudo Executivo</button>
                 <button onClick={() => generateAnalyticReport(clients.find(c => c.id === selectedClientId)!, results.summary)} className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-wider"><Settings size={14} /> Laudo Técnico Analítico</button>
                 <button onClick={handleSaveProcess} className="flex items-center gap-2 bg-emerald-600 text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-wider"><Save size={14} /> Salvar/Protocolar</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
