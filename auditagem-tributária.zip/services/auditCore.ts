
import { AuditItem, MonthlyResult } from '../types';
import { db } from './db';

const CFOP_VENDAS = new Set([
  '5101', '5102', '5103', '5104', '5403', '5405',
  '6101', '6102', '6108', '6403', '6404'
]);

// Esta base servirá apenas como fallback se a base do banco estiver vazia
const BASE_NCM_FALLBACK = [
  '22011000', '22019000', '22021000', '22029100', '22029900', '22030000',
  '30039048', '30049029', '30049099', '30045090', '30042099', '30043918',
  '30012010', '30021229', '30051010', '30066000',
  '87082999', '87089990', '87083090', '40111000', '40112090', '84133010', '84148019',
  '84073390', '84082090', '84099190', '84099990', '85111000', '85122011',
  '33030010', '33049910', '33051000', '33061000', '33072010', '33071000',
  '34011190', '34011110', '34012010', '96032100'
];

export const getEstimatedTaxRate = (faturamentoMensal: number): number => {
  if (faturamentoMensal <= 15000) return 0.0062;
  if (faturamentoMensal <= 30000) return 0.0113;
  if (faturamentoMensal <= 60000) return 0.0147;
  if (faturamentoMensal <= 150000) return 0.0166;
  return 0.0222;
};

const normalizarNCM = (ncm: string): string => ncm.replace(/\./g, '').trim();

/**
 * Gera auditoria simulada baseada em parâmetros reais do usuário
 * @param baseFaturamento Valor médio mensal informado
 * @param pctMonofasico Percentual de produtos monofásicos (0-100)
 */
export const gerarAuditoriaSimulada = (baseFaturamento: number, pctMonofasico: number): MonthlyResult[] => {
  const data: MonthlyResult[] = [];
  const hoje = new Date();
  
  for (let i = 60; i >= 1; i--) {
    const dataRef = new Date(hoje.getFullYear(), hoje.getMonth() - i, 1);
    const competencia = dataRef.toISOString().substring(0, 7);
    
    // Variação randômica de +/- 10% no faturamento para parecer real
    const variacao = 0.9 + (Math.random() * 0.2);
    const receitaBruta = baseFaturamento * variacao;
    
    // Percentual monofásico com leve oscilação
    const variacaoPct = 0.95 + (Math.random() * 0.1);
    const baseMonofasica = receitaBruta * (pctMonofasico / 100) * variacaoPct;
    
    data.push({
      competencia,
      receitaBruta,
      baseMonofasica,
      baseNormal: receitaBruta - baseMonofasica,
      pctSegregacao: (baseMonofasica / receitaBruta) * 100
    });
  }
  return data;
};

export const processarXMLs = async (files: FileList): Promise<{ items: AuditItem[], summary: MonthlyResult[] }> => {
  // CRÍTICO: Carregamos a inteligência das Tabelas Técnicas do banco
  const ncmList = db.getNCMs();
  
  // Se não houver NCMs cadastrados, usa o fallback, senão usa apenas o que o admin cadastrou
  const NCM_BASE = ncmList.length > 0 
    ? ncmList.map(i => normalizarNCM(i.ncm)) 
    : BASE_NCM_FALLBACK.map(n => normalizarNCM(n));

  const NCM_MONOFASICOS = new Set(NCM_BASE);
  const items: AuditItem[] = [];
  const parser = new DOMParser();

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    try {
      const text = await file.text();
      const xmlDoc = parser.parseFromString(text, "text/xml");
      if (xmlDoc.getElementsByTagName("parsererror").length > 0) continue;

      const dhEmiTag = xmlDoc.getElementsByTagName('dhEmi')[0] || xmlDoc.getElementsByTagName('dEmi')[0];
      const dataEmissao = dhEmiTag ? dhEmiTag.textContent?.split('T')[0] : '';
      const nNFTag = xmlDoc.getElementsByTagName('nNF')[0];
      const nNF = nNFTag ? nNFTag.textContent || 'S/N' : 'S/N';
      if (!dataEmissao) continue;

      const detElements = xmlDoc.getElementsByTagName('det');
      for (let j = 0; j < detElements.length; j++) {
        const prod = detElements[j].getElementsByTagName('prod')[0];
        if (!prod) continue;
        const cfop = prod.getElementsByTagName('CFOP')[0]?.textContent || '';
        if (!CFOP_VENDAS.has(cfop)) continue;
        const ncmRaw = prod.getElementsByTagName('NCM')[0]?.textContent || '';
        const ncm = normalizarNCM(ncmRaw);
        const vProd = parseFloat(prod.getElementsByTagName('vProd')[0]?.textContent || '0');
        
        // Verifica NCM completo ou os primeiros 4 dígitos (capítulo)
        const isMonofasico = NCM_MONOFASICOS.has(ncm) || NCM_MONOFASICOS.has(ncm.substring(0, 4));

        items.push({
          id: `${nNF}-${j}`,
          nNF,
          dataEmissao,
          ncm,
          descricao: prod.getElementsByTagName('xProd')[0]?.textContent || '',
          cfop,
          valor: vProd,
          statusTributario: isMonofasico ? 'Monofásico' : 'Normal',
          riscoAuditoria: false
        });
      }
    } catch (e) { console.error(e); }
  }

  const summaryMap = new Map<string, MonthlyResult>();
  items.forEach(item => {
    const competencia = item.dataEmissao.substring(0, 7);
    if (!summaryMap.has(competencia)) {
      summaryMap.set(competencia, { competencia, receitaBruta: 0, baseMonofasica: 0, baseNormal: 0, pctSegregacao: 0 });
    }
    const current = summaryMap.get(competencia)!;
    current.receitaBruta += item.valor;
    if (item.statusTributario === 'Monofásico') current.baseMonofasica += item.valor;
    else current.baseNormal += item.valor;
  });

  return { 
    items, 
    summary: Array.from(summaryMap.values()).map(s => ({
      ...s,
      pctSegregacao: s.receitaBruta > 0 ? (s.baseMonofasica / s.receitaBruta) * 100 : 0
    })).sort((a, b) => a.competencia.localeCompare(b.competencia))
  };
};
