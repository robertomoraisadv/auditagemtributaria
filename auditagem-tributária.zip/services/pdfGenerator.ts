import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { MonthlyResult, Client } from '../types';
import { getEstimatedTaxRate } from './auditCore';

const COLORS = {
  PRIMARY: [0, 51, 102] as [number, number, number],
  BLUE_LIGHT: [14, 165, 233] as [number, number, number],
  SECONDARY: [71, 85, 105] as [number, number, number],
  SUCCESS: [22, 163, 74] as [number, number, number],
  DANGER: [185, 28, 28] as [number, number, number],
  BG_HIGHLIGHT: [240, 253, 244] as [number, number, number],
  TEXT_BODY: [30, 41, 59] as [number, number, number],
};

const fmtBRL = (val: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

/**
 * Helper para gerar gráfico de pizza em Base64 usando Canvas (Substitui Matplotlib no Browser)
 */
const generatePieChartBase64 = (normal: number, mono: number): string => {
  const canvas = document.createElement('canvas');
  canvas.width = 400;
  canvas.height = 400;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  const total = normal + mono;
  const angles = [(normal / total) * 2 * Math.PI, (mono / total) * 2 * Math.PI];
  const colors = ['#e2e8f0', '#3b82f6']; // Cinza (Devido) e Azul (Recuperável)
  
  let startAngle = -Math.PI / 2;
  angles.forEach((angle, i) => {
    ctx.beginPath();
    ctx.moveTo(200, 200);
    ctx.arc(200, 200, 180, startAngle, startAngle + angle);
    ctx.fillStyle = colors[i];
    ctx.fill();
    startAngle += angle;
  });

  // Efeito Donut
  ctx.beginPath();
  ctx.arc(200, 200, 100, 0, 2 * Math.PI);
  ctx.fillStyle = '#ffffff';
  ctx.fill();

  return canvas.toDataURL('image/png');
};

class PDFReport {
  protected doc: jsPDF;
  protected clientName: string;

  constructor(clientName: string) {
    this.doc = new jsPDF();
    this.clientName = clientName;
  }

  protected addHeader(title: string) {
    const doc = this.doc;
    doc.setFillColor(...COLORS.PRIMARY);
    doc.rect(0, 0, 210, 15, 'F');
    doc.setFontSize(8);
    doc.setTextColor(255, 255, 255);
    doc.setFont(undefined, 'bold');
    doc.text("GOLD AUDITAGEM TRIBUTÁRIA - INTELIGÊNCIA FISCAL & SUPORTE JURÍDICO", 105, 10, { align: 'center' });
    
    doc.setFontSize(14);
    doc.setTextColor(...COLORS.PRIMARY);
    doc.text(title.toUpperCase(), 14, 30);
    doc.setDrawColor(...COLORS.PRIMARY);
    doc.setLineWidth(0.5);
    doc.line(14, 33, 80, 33);
  }

  protected addFooter(pageType: string) {
    const pageCount = this.doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      this.doc.setPage(i);
      this.doc.setFontSize(8);
      this.doc.setTextColor(150);
      this.doc.text(`Laudo ${pageType} | Auditagem TributárIA | Página ${i} de ${pageCount}`, 105, 285, { align: 'center' });
    }
  }

  public save(filename: string, type: string) {
    this.addFooter(type);
    this.doc.save(filename);
  }
}

/**
 * RELATÓRIO EXECUTIVO (3 PÁGINAS) - FOCO JURÍDICO-COMERCIAL
 */
export const generateExecutiveReport = (client: Client | { razao_social: string; nome_contato?: string }, summary: MonthlyResult[]) => {
  const report = new PDFReport(client.razao_social);
  const doc = report['doc'] as any;
  const totalRec = summary.reduce((acc, curr) => acc + (curr.baseMonofasica * getEstimatedTaxRate(curr.receitaBruta)), 0);
  const totalFaturamento = summary.reduce((acc, curr) => acc + curr.receitaBruta, 0);
  const totalMono = summary.reduce((acc, curr) => acc + curr.baseMonofasica, 0);
  const totalNormal = totalFaturamento - totalMono;

  // --- PÁGINA 1: CARTA DE APRESENTAÇÃO (TEXTO JURÍDICO-COMERCIAL) ---
  report['addHeader']("Diagnóstico de Eficiência Tributária e Blindagem Jurídica");
  let y = 50;
  doc.setFontSize(11);
  doc.setTextColor(...COLORS.TEXT_BODY);
  doc.setFont(undefined, 'bold');
  doc.text(`Prezado(a) ${client.nome_contato || 'Gestor(a)'},`, 14, y); y += 10;
  
  doc.setFont(undefined, 'normal');
  const corpoTexto = [
    `É com satisfação que apresentamos o resultado do Diagnóstico Estratégico de Recuperação de Créditos da ${client.razao_social}.`,
    "",
    "1. A NATUREZA DO CRÉDITO (DIREITO, NÃO FALHA)",
    "Este levantamento não aponta erros de sua gestão contábil. A oportunidade nasce de uma especificidade do Simples Nacional: o sistema cobra alíquota cheia sobre produtos que já foram tributados na indústria (Monofásicos). Nossa auditoria segregou esses itens para evitar o pagamento em duplicidade, gerando caixa imediato.",
    "",
    "2. SEGURANÇA JURÍDICA E PRESCRIÇÃO",
    "O procedimento tem base na Lei Complementar 123/2006 e é pacificado pelo STJ e PGFN. Alertamos, contudo, para o prazo prescricional de 5 anos: a cada mês de inércia, perde-se definitivamente o direito sobre a competência mais antiga.",
    "",
    "3. SUPORTE JURÍDICO INTEGRAL (SEM CUSTOS ADICIONAIS)",
    "Nosso compromisso vai além da recuperação. A empresa contará com suporte jurídico completo de nossa equipe para dirimir eventuais questionamentos futuros do fisco sobre estes créditos. Esta \"blindagem\" já está inclusa nos honorários de êxito.",
    "",
    "4. PARCERIA ESTRATÉGICA",
    "Ao tornar-se nosso cliente na área tributária, sua empresa passa a contar também com condições especiais e tabelas diferenciadas caso necessite de atuação jurídica em outros ramos do direito (Trabalhista, Cível, Contratual).",
    "",
    "Atenciosamente,",
    "Equipe Auditagem TributárIA"
  ];

  const introSplit = doc.splitTextToSize(corpoTexto.join('\n'), 182);
  doc.text(introSplit, 14, y);

  // --- PÁGINA 2: DEMONSTRAÇÃO FINANCEIRA VISUAL ---
  doc.addPage();
  report['addHeader']("Demonstração Financeira de Créditos");
  y = 45;
  
  autoTable(doc, {
    startY: y,
    head: [['Indicador Estratégico', 'Valor Identificado (Acumulado 60 Meses)']],
    body: [
      ['Faturamento Total Analisado', fmtBRL(totalFaturamento)],
      ['Base de Produtos Monofásicos', fmtBRL(totalMono)],
      ['POTENCIAL DE RECUPERAÇÃO IDENTIFICADO', fmtBRL(totalRec)]
    ],
    theme: 'striped',
    headStyles: { fillColor: COLORS.PRIMARY, fontSize: 10 },
    styles: { fontSize: 10, cellPadding: 5 },
    columnStyles: { 1: { fontStyle: 'bold', halign: 'right' } }
  });

  y = (doc as any).lastAutoTable.finalY + 15;
  doc.setFont(undefined, 'bold');
  doc.text("Carga Tributária: Pago Indevidamente vs. Devido", 105, y, { align: 'center' });
  
  const chartImg = generatePieChartBase64(totalNormal, totalMono);
  doc.addImage(chartImg, 'PNG', 55, y + 5, 100, 100);

  y += 115;
  doc.setFontSize(9);
  doc.setTextColor(...COLORS.BLUE_LIGHT);
  doc.text(`[●] Valor Recuperável (Monofásico): ${fmtBRL(totalRec)}`, 55, y);
  doc.setTextColor(150);
  doc.text(`[●] Imposto Devido (Normal): ${fmtBRL(totalFaturamento - totalMono)}`, 55, y + 6);

  // --- PÁGINA 3: DOCUMENTAÇÃO E JUSTIFICATIVA TÉCNICA ---
  doc.addPage();
  report['addHeader']("Protocolo Operacional e Documental");
  y = 50;
  
  const docs = [
    { item: "Certificado Digital A1", motivo: "Por que é necessário? Essencial para acessar o e-CAC e assinar os termos de retificação e pedido de restituição eletrônica com validade jurídica." },
    { item: "Arquivos XML (NFe/NFCe)", motivo: "Por que é necessário? São a prova primária da venda de itens monofásicos. Sem eles, a auditoria não possui lastro para defesa em caso de fiscalização." },
    { item: "Extratos PGDAS-D", motivo: "Por que é necessário? Servem para confrontar o que foi pago originalmente e calcular a exata diferença a ser restituída pela Receita Federal." },
    { item: "Dados Bancários (PJ)", motivo: "Por que é necessário? A restituição é depositada diretamente na conta corrente vinculada ao CNPJ da empresa, sem intermediários." }
  ];

  docs.forEach(d => {
    doc.setFont(undefined, 'bold');
    doc.setFontSize(10);
    doc.setTextColor(...COLORS.PRIMARY);
    doc.text(`● ${d.item}`, 14, y);
    y += 5;
    doc.setFont(undefined, 'normal');
    doc.setFontSize(9);
    doc.setTextColor(...COLORS.TEXT_BODY);
    const motivoText = doc.splitTextToSize(d.motivo, 175);
    doc.text(motivoText, 20, y);
    y += (motivoText.length * 5) + 5;
  });

  report.save(`Executivo_${client.razao_social.replace(/\s+/g, '_')}.pdf`, "Executivo");
};

/**
 * RELATÓRIO TÉCNICO (2 PÁGINAS) - PRESERVADO PARA O CONTADOR
 */
export const generateAnalyticReport = (client: Client | { razao_social: string }, summary: MonthlyResult[]) => {
  const report = new PDFReport(client.razao_social);
  const doc = report['doc'] as any;
  const totalBase = summary.reduce((a, b) => a + b.baseMonofasica, 0);
  const totalCredito = summary.reduce((a, b) => a + (b.baseMonofasica * getEstimatedTaxRate(b.receitaBruta)), 0);

  // --- PÁGINA 1: TABELA ANALÍTICA ---
  report['addHeader']("Relatório Técnico de Apuração (Analítico)");
  
  autoTable(doc, {
    startY: 45,
    head: [['Competência', 'Faturamento Bruto', 'Base Monofásica', 'Alíquota Efetiva', 'Crédito Estimado']],
    body: summary.map(s => {
      const rate = getEstimatedTaxRate(s.receitaBruta);
      return [
        s.competencia,
        fmtBRL(s.receitaBruta),
        fmtBRL(s.baseMonofasica),
        `${(rate * 100).toFixed(2)}%`,
        fmtBRL(s.baseMonofasica * rate)
      ];
    }),
    foot: [['TOTAL ACUMULADO', '-', fmtBRL(totalBase), '-', fmtBRL(totalCredito)]],
    theme: 'grid',
    styles: { fontSize: 7, cellPadding: 2 },
    headStyles: { fillColor: COLORS.PRIMARY },
    footStyles: { fillColor: [240, 240, 240], textColor: COLORS.PRIMARY, fontStyle: 'bold' }
  });

  // --- PÁGINA 2: GUIA PGDAS ---
  doc.addPage();
  report['addHeader']("Manual de Retificação PGDAS-D");
  let y = 50;
  doc.setFontSize(10);
  doc.setFont(undefined, 'bold');
  doc.text("PASSOS PARA SEGREGAÇÃO DE RECEITA NO PORTAL E-CAC:", 14, y); y += 10;
  
  const steps = [
    "1. Acesse o menu PGDAS-D e Defis > Declaração Mensal > Retificar.",
    "2. Identifique a receita bruta total conforme declarado anteriormente.",
    "3. No campo de atividades, selecione 'Venda de mercadorias com substituição tributária/monofásica'.",
    "4. Utilize os valores da coluna 'Base Monofásica' pág 1 para cada competência.",
    "5. Verifique se o sistema reduziu automaticamente os valores de PIS e COFINS.",
    "6. Após transmitir, emita o novo DAS (se houver saldo) e protocole o pedido de restituição via PER/DCOMP Web."
  ];
  
  doc.setFont(undefined, 'normal');
  steps.forEach(step => {
    doc.text(step, 14, y);
    y += 8;
  });

  y += 10;
  doc.setFillColor(...COLORS.BG_HIGHLIGHT);
  doc.rect(14, y, 182, 20, 'F');
  doc.setFontSize(9);
  doc.setFont(undefined, 'bold');
  doc.text("CONFORMIDADE: A memória de cálculo acima utiliza a Lei Complementar 123/2006 Art. 18, § 4º-A.", 20, y + 12);

  report.save(`Tecnico_Analitico_${client.razao_social.replace(/\s+/g, '_')}.pdf`, "Técnico");
};

/**
 * RELATÓRIO DE SIMULAÇÃO (COMPACTO)
 */
export const generateSimulationReport = (
  clientName: string, faturamentoMensal: number, meses: number, percentualMonofasico: number, _unused: string, appliedRate: number
) => {
  const report = new PDFReport(clientName);
  const doc = report['doc'];
  report['addHeader']("Simulação Comercial de Recuperação");
  const totalRec = faturamentoMensal * percentualMonofasico * meses * appliedRate;
  
  let y = 50;
  doc.setFontSize(10);
  doc.setFont(undefined, 'bold');
  doc.text("ESTIMATIVA PRELIMINAR DE CRÉDITOS:", 14, y);
  
  autoTable(doc, {
    startY: y + 5,
    body: [
      ['Faturamento Mensal Estimado', fmtBRL(faturamentoMensal)],
      ['Incidência Monofásica Média', `${(percentualMonofasico * 100).toFixed(0)}%`],
      ['Crédito Acumulado (60 meses)', fmtBRL(totalRec)]
    ],
    theme: 'plain',
    styles: { fontSize: 10 }
  });

  const finalY = (doc as any).lastAutoTable.finalY + 20;
  doc.setFillColor(...COLORS.BG_HIGHLIGHT);
  doc.rect(14, finalY, 182, 30, 'F');
  doc.setFontSize(16);
  doc.setTextColor(...COLORS.SUCCESS);
  doc.text("CAIXA ESTIMADO: " + fmtBRL(totalRec), 105, finalY + 18, { align: 'center' });
  
  report.save(`Simulacao_${clientName.replace(/\s+/g, '_')}.pdf`, "Simulação");
};
