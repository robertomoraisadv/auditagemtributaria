

import { Client, User, AuditProcess, NCMData, AppConfig, ProcessStatus } from '../types';

const DB_KEYS = {
  USERS: 'erp_v11_gold_v3_users',
  CLIENTS: 'erp_v11_gold_v3_clients',
  PROCESSES: 'erp_v11_gold_v3_processes',
  NCMS: 'erp_v11_gold_v3_ncms',
  SETTINGS: 'erp_v11_gold_v3_settings'
};

export const cleanNumbers = (val: string) => {
  if (!val) return '';
  return val.replace(/\D/g, '');
};

const SEED_NCMS: NCMData[] = [
  { ncm: '22030000', categoria: 'Bebidas', descricao: 'Cervejas de malte' },
  { ncm: '22021000', categoria: 'Bebidas', descricao: 'Águas minerais e gaseificadas com açúcar' },
  { ncm: '22011000', categoria: 'Bebidas', descricao: 'Águas minerais naturais e gaseificadas' },
  { ncm: '87089990', categoria: 'Autopeças', descricao: 'Outras partes e acessórios de veículos' },
  { ncm: '40111000', categoria: 'Autopeças', descricao: 'Pneus novos de borracha para automóveis' },
  { ncm: '30049099', categoria: 'Farmácia', descricao: 'Medicamentos - Outros' },
  { ncm: '33049990', categoria: 'Perfumaria', descricao: 'Produtos de beleza ou maquilagem' },
  { ncm: '34011190', categoria: 'Higiene', descricao: 'Sabões e produtos tensoativos' },
  { ncm: '38119000', categoria: 'Combustíveis', descricao: 'Aditivos para óleos lubrificantes' },
  { ncm: '27111910', categoria: 'Gás', descricao: 'Gás liquefeito de petróleo (GLP)' }
];

export const LISTA_UFS = ["AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO"];
export const SETORES = ["Autopeças", "Farmácia", "Perfumaria", "Bares/Restaurantes", "Bebidas", "Gás (GLP)", "Pet Shop", "Mercados", "Pneus", "Outros"];

const DEFAULT_ADMIN: User = {
  id: 'admin-v11-gold',
  nome: 'Administrador Master',
  email: 'auditagemtributaria@gmail.com',
  senha_hash: 'tq3v2p6m',
  funcao: 'admin',
  cpf: '00000000000',
  sexo: 'M',
  whatsapp: '00000000000',
  chave_pix: 'auditagem@pix.com',
  comissao_percentual: 0,
  cep: '00000000',
  logradouro: 'Avenida Principal',
  numero: '1000',
  bairro: 'Centro',
  uf: 'SP',
  cidade: 'São Paulo',
  bloqueado: false
};

class DatabaseService {
  constructor() {
    this.init();
  }

  init() {
    if (!localStorage.getItem(DB_KEYS.USERS)) {
      this.hardReset();
    }
    if (this.getNCMs().length === 0) {
      this.updateNCMs(SEED_NCMS);
    }
  }

  hardReset() {
    localStorage.clear();
    localStorage.setItem(DB_KEYS.USERS, JSON.stringify([DEFAULT_ADMIN]));
    localStorage.setItem(DB_KEYS.CLIENTS, JSON.stringify([]));
    localStorage.setItem(DB_KEYS.PROCESSES, JSON.stringify([]));
    localStorage.setItem(DB_KEYS.SETTINGS, JSON.stringify({ smtp_email: '', smtp_senha: '' }));
    localStorage.setItem(DB_KEYS.NCMS, JSON.stringify(SEED_NCMS));
  }

  getNCMs(): NCMData[] { return JSON.parse(localStorage.getItem(DB_KEYS.NCMS) || '[]'); }
  updateNCMs(data: NCMData[]) { localStorage.setItem(DB_KEYS.NCMS, JSON.stringify(data)); }
  getUsers(): User[] { return JSON.parse(localStorage.getItem(DB_KEYS.USERS) || '[]'); }
  
  addUser(user: Omit<User, 'id' | 'bloqueado'>): boolean {
    const users = this.getUsers();
    if (users.some(u => u.email.toLowerCase() === user.email.toLowerCase())) return false;
    users.push({ ...user, id: crypto.randomUUID(), bloqueado: false, cpf: cleanNumbers(user.cpf), whatsapp: cleanNumbers(user.whatsapp) });
    localStorage.setItem(DB_KEYS.USERS, JSON.stringify(users));
    return true;
  }

  updateUser(id: string, updates: Partial<User>): boolean {
    const users = this.getUsers();
    const idx = users.findIndex(u => u.id === id);
    if (idx === -1) return false;
    users[idx] = { ...users[idx], ...updates };
    localStorage.setItem(DB_KEYS.USERS, JSON.stringify(users));
    return true;
  }

  deleteUser(id: string): boolean {
    if (id === 'admin-v11-gold') return false;
    const users = this.getUsers().filter(u => u.id !== id);
    localStorage.setItem(DB_KEYS.USERS, JSON.stringify(users));
    return true;
  }

  authenticate(email: string, pass: string) {
    const user = this.getUsers().find(u => u.email.toLowerCase() === email.toLowerCase() && u.senha_hash === pass);
    if (user) return user.bloqueado ? { user: null, error: '⚠️ ACESSO BLOQUEADO.' } : { user };
    return { user: null, error: 'Credenciais inválidas.' };
  }

  getClients(userId?: string, isAdmin: boolean = false): Client[] {
    const list: Client[] = JSON.parse(localStorage.getItem(DB_KEYS.CLIENTS) || '[]');
    return isAdmin ? list : list.filter(c => c.id_parceiro_vinculado === userId);
  }

  addClient(client: Omit<Client, 'id' | 'data_cadastro' | 'status_processo'>): boolean {
    const list = this.getClients(undefined, true);
    if (list.some(c => c.cnpj === cleanNumbers(client.cnpj))) return false;
    list.push({ ...client, id: crypto.randomUUID(), data_cadastro: new Date().toISOString(), status_processo: 'Prospecção', cnpj: cleanNumbers(client.cnpj) });
    localStorage.setItem(DB_KEYS.CLIENTS, JSON.stringify(list));
    return true;
  }

  getProcesses(userId?: string, isAdmin: boolean = false): AuditProcess[] {
    const list: AuditProcess[] = JSON.parse(localStorage.getItem(DB_KEYS.PROCESSES) || '[]');
    return isAdmin ? list : list.filter(p => p.id_parceiro === userId);
  }

  /**
   * Lógica de UPSERT Tributário:
   * Verifica se há processo aberto para o cliente. 
   * Se sim, atualiza. Se não, cria.
   */
  saveAuditProcess(data: Partial<AuditProcess>): { success: boolean, action: 'created' | 'updated' } {
    const list = this.getProcesses(undefined, true);
    const users = this.getUsers();
    const partner = users.find(u => u.id === data.id_parceiro);
    
    // Busca processo existente "Aberto" para o cliente
    // Fixed: 'Cancelado' comparison is now valid after adding it to the ProcessStatus type in types.ts
    const existingIdx = list.findIndex(p => p.id_cliente === data.id_cliente && p.status_processo !== 'Finalizado' && p.status_processo !== 'Cancelado');

    const valor_estimado = data.valor_estimado || 0;
    const pct_honorarios = data.pct_honorarios || 30;
    const valor_honorarios = valor_estimado * (pct_honorarios / 100);
    const pct_comissao = partner?.comissao_percentual || 10;
    const valor_comissao = valor_honorarios * (pct_comissao / 100);

    if (existingIdx !== -1) {
      // UPDATE
      const existing = list[existingIdx];
      list[existingIdx] = {
        ...existing,
        ...data,
        valor_estimado,
        valor_honorarios,
        valor_comissao_parceiro: valor_comissao,
        created_at: existing.created_at // Mantém a data original de criação
      };
      localStorage.setItem(DB_KEYS.PROCESSES, JSON.stringify(list));
      return { success: true, action: 'updated' };
    } else {
      // INSERT
      const newProcess: AuditProcess = {
        id: crypto.randomUUID(),
        id_cliente: data.id_cliente || '',
        id_parceiro: data.id_parceiro || 'admin',
        periodo_inicio: data.periodo_inicio || '',
        periodo_fim: data.periodo_fim || '',
        status_processo: data.status_processo || 'Prospecção',
        check_pgdas: data.check_pgdas || false,
        valor_estimado,
        valor_homologado: 0,
        pct_honorarios,
        valor_honorarios,
        status_pgto_cliente: 'A Faturar' as any,
        pct_comissao_parceiro: pct_comissao,
        valor_comissao_parceiro: valor_comissao,
        status_pgto_parceiro: 'Aguardando Cliente',
        tipo_origem: data.tipo_origem || 'SIMULACAO',
        log_auditoria: data.log_auditoria || '',
        created_at: new Date().toISOString()
      };
      list.push(newProcess);
      localStorage.setItem(DB_KEYS.PROCESSES, JSON.stringify(list));
      return { success: true, action: 'created' };
    }
  }

  updateProcess(id: string, updates: Partial<AuditProcess>): boolean {
    const list = this.getProcesses(undefined, true);
    const idx = list.findIndex(p => p.id === id);
    if (idx === -1) return false;

    const current = list[idx];
    const merged = { ...current, ...updates };

    if (updates.valor_homologado !== undefined || updates.pct_honorarios !== undefined) {
      const base = merged.valor_homologado > 0 ? merged.valor_homologado : merged.valor_estimado;
      merged.valor_honorarios = base * (merged.pct_honorarios / 100);
      merged.valor_comissao_parceiro = merged.valor_honorarios * (merged.pct_comissao_parceiro / 100);
    }

    list[idx] = merged;
    localStorage.setItem(DB_KEYS.PROCESSES, JSON.stringify(list));
    return true;
  }

  deleteProcess(id: string): boolean {
    const list = this.getProcesses(undefined, true);
    const filtered = list.filter(p => p.id !== id);
    localStorage.setItem(DB_KEYS.PROCESSES, JSON.stringify(filtered));
    return true;
  }

  getConfig(key: keyof AppConfig): string {
    const s = JSON.parse(localStorage.getItem(DB_KEYS.SETTINGS) || '{}');
    return s[key] || '';
  }
  setConfig(key: keyof AppConfig, val: string) {
    const s = JSON.parse(localStorage.getItem(DB_KEYS.SETTINGS) || '{}');
    s[key] = val;
    localStorage.setItem(DB_KEYS.SETTINGS, JSON.stringify(s));
  }
  getAllConfig(): AppConfig { return JSON.parse(localStorage.getItem(DB_KEYS.SETTINGS) || '{}'); }
  createBackup() { return JSON.stringify({ clients: this.getClients(undefined, true), processes: this.getProcesses(undefined, true), users: this.getUsers(), ncms: this.getNCMs() }, null, 2); }
}

export const db = new DatabaseService();