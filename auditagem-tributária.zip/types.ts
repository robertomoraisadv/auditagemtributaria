

export type Role = 'admin' | 'parceiro';
export type Sexo = 'M' | 'F';

export interface User {
  id: string;
  email: string;
  senha_hash: string;
  nome: string;
  funcao: Role;
  cpf: string;
  sexo: Sexo;
  whatsapp: string;
  chave_pix: string;
  comissao_percentual: number;
  cep: string;
  logradouro: string;
  numero: string;
  bairro: string;
  uf: string;
  cidade: string;
  bloqueado: boolean;
}

export enum RegimeTributario {
  SIMPLES_COMERCIO = "Simples Nacional - Anexo I (Comércio)",
  SIMPLES_OUTROS = "Simples Nacional - Outros"
}

// Fixed: Added 'Cancelado' to ProcessStatus type to fix type overlap and assignment errors in components
export type ProcessStatus = 'Prospecção' | 'Em Análise' | 'Protocolado' | 'Homologado' | 'Finalizado' | 'Arquivado' | 'Cancelado';
export type FinancialStatus = 'A Faturar' | 'Aguardando Pagamento' | 'Pago' | 'Inadimplente';
export type PartnerPaymentStatus = 'Aguardando Cliente' | 'Liberado' | 'Pago';

export interface Client {
  id: string;
  cnpj: string;
  razao_social: string;
  nome_contato: string;
  whatsapp: string;
  email: string;
  uf: string;        
  cidade: string;
  setor: string;
  rbt12_atual: number;
  regime_tributario: RegimeTributario;
  id_parceiro_vinculado: string; 
  data_cadastro: string;
  status_processo: ProcessStatus;
}

export interface AuditProcess {
  id: string;
  id_cliente: string;  
  id_parceiro: string; 
  periodo_inicio: string; 
  periodo_fim: string;    
  status_processo: ProcessStatus;
  check_pgdas: boolean; 
  valor_estimado: number;      // Do simulador
  valor_homologado: number;    // Real da Receita
  pct_honorarios: number;       
  valor_honorarios: number;    // Calculado
  status_pgto_cliente: FinancialStatus;
  pct_comissao_parceiro: number; 
  valor_comissao_parceiro: number; // Calculado
  status_pgto_parceiro: PartnerPaymentStatus;
  data_pagamento?: string;
  tipo_origem: 'SIMULACAO' | 'XML';
  log_auditoria: string;
  created_at: string;
}

export interface AuditItem {
  id: string;
  nNF: string;
  dataEmissao: string;
  ncm: string;
  descricao: string;
  cfop: string;
  valor: number;
  statusTributario: 'Normal' | 'Monofásico';
  riscoAuditoria: boolean;
}

export interface MonthlyResult {
  competencia: string;
  receitaBruta: number;
  baseMonofasica: number;
  baseNormal: number;
  pctSegregacao: number;
}

export type ViewState = 
  | 'dashboard' 
  | 'register_client' 
  | 'sales_simulator' 
  | 'audit_xml' 
  | 'technical_tables' 
  | 'reports_history' 
  | 'partner_management' 
  | 'system_settings' 
  | 'production_crm' 
  | 'management_reports';

export interface NCMData {
  ncm: string;
  categoria: string;
  descricao: string;
}

export interface AppConfig {
  smtp_email: string;
  smtp_senha: string;
}